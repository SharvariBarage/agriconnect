/**
 * Dashboard Routes
 */

const express = require('express');
const router = express.Router();
const { auth, authorize } = require('../middleware/auth');
const { farmerDashboard, buyerDashboard } = require('../controllers/dashboardController');

router.get('/farmer', auth, authorize('farmer'), farmerDashboard);
router.get('/buyer', auth, authorize('buyer'), buyerDashboard);

module.exports = router;
