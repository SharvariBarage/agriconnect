/**
 * Fertilizer Routes
 */

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
    createProduct, getProducts, getProductById,
    updateProduct, deleteProduct
} = require('../controllers/fertilizerController');

// Public routes
router.get('/', getProducts);
router.get('/:id', getProductById);

// Protected routes
router.post('/', auth, upload.multiple('images', 5), createProduct);
router.put('/:id', auth, upload.multiple('images', 5), updateProduct);
router.delete('/:id', auth, deleteProduct);

module.exports = router;
