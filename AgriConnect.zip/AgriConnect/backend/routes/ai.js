/**
 * AI Assistant Routes
 */

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const { chat, getSuggestions } = require('../controllers/aiController');

router.get('/suggestions', getSuggestions);
router.post('/chat', auth, chat);

module.exports = router;
