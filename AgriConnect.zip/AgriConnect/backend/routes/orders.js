/**
 * Order Routes
 */

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const {
    placeOrder, getOrders, getOrderById, updateOrderStatus, cancelOrder
} = require('../controllers/orderController');

router.get('/', auth, getOrders);
router.get('/:id', auth, getOrderById);
router.post('/', auth, placeOrder);
router.put('/:id/status', auth, updateOrderStatus);
router.put('/:id/cancel', auth, cancelOrder);

module.exports = router;
