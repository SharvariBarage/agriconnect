/**
 * Cart Routes
 */

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const {
    getCart, addToCart, updateCartItem, removeFromCart, clearCart
} = require('../controllers/cartController');

router.get('/', auth, getCart);
router.post('/', auth, addToCart);
router.put('/:productId', auth, updateCartItem);
router.delete('/:productId', auth, removeFromCart);
router.delete('/', auth, clearCart);

module.exports = router;
