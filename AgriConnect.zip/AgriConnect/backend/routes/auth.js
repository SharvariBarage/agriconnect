/**
 * Authentication Routes
 */

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const {
    register, login, getProfile, updateProfile, getUsers, getUserById
} = require('../controllers/authController');

// Public routes
router.post('/register', register);
router.post('/login', login);

// Protected routes
router.get('/me', auth, getProfile);
router.put('/profile', auth, updateProfile);
router.get('/users', auth, getUsers);
router.get('/users/:id', auth, getUserById);

module.exports = router;
