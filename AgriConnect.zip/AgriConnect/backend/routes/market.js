/**
 * Market Price Routes
 */

const express = require('express');
const router = express.Router();
const { getPrices, getTrends, searchCrops } = require('../controllers/marketController');

router.get('/prices', getPrices);
router.get('/trends', getTrends);
router.get('/search', searchCrops);

module.exports = router;
