/**
 * Crop Routes
 */

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
    createCrop, getCrops, getCropById, updateCrop, deleteCrop,
    submitInquiry, getInquiries
} = require('../controllers/cropController');

// Public routes
router.get('/', getCrops);
router.get('/inquiries', auth, getInquiries);
router.get('/:id', getCropById);

// Protected routes (require authentication)
router.post('/', auth, upload.multiple('images', 5), createCrop);
router.put('/:id', auth, upload.multiple('images', 5), updateCrop);
router.delete('/:id', auth, deleteCrop);
router.post('/:id/inquiry', auth, submitInquiry);

module.exports = router;
