/**
 * Equipment Routes
 */

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
    createEquipment, getEquipment, getEquipmentById,
    bookEquipment, getBookings, deleteEquipment
} = require('../controllers/equipmentController');

// Public routes
router.get('/', getEquipment);
router.get('/bookings', auth, getBookings);
router.get('/:id', getEquipmentById);

// Protected routes
router.post('/', auth, upload.multiple('images', 5), createEquipment);
router.post('/:id/book', auth, bookEquipment);
router.delete('/:id', auth, deleteEquipment);

module.exports = router;
