/**
 * Cart Model
 * Shopping cart for buyers
 */

const mongoose = require('mongoose');

const cartItemSchema = new mongoose.Schema({
    productType: {
        type: String,
        enum: ['crop', 'fertilizer'],
        required: true
    },
    productId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        refPath: 'productType'
    },
    quantity: {
        type: Number,
        required: true,
        min: [1, 'Quantity must be at least 1']
    },
    price: {
        type: Number,
        required: true
    }
});

const cartSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        unique: true
    },
    items: [cartItemSchema]
}, { timestamps: true });

// Calculate total
cartSchema.methods.getTotal = function() {
    return this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
};

module.exports = mongoose.model('Cart', cartSchema);
