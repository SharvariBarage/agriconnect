/**
 * Equipment Model
 * For agricultural equipment rental (tractors, harvesters, pumps, etc.)
 */

const mongoose = require('mongoose');

const equipmentSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Equipment title is required'],
        trim: true
    },
    category: {
        type: String,
        required: true,
        enum: ['tractor', 'harvester', 'pump', 'sprayer', 'plough', 'rotavator', 'seeder', 'thresher', 'other']
    },
    description: {
        type: String,
        trim: true
    },
    pricePerDay: {
        type: Number,
        required: true,
        min: [0, 'Price cannot be negative']
    },
    pricePerHour: {
        type: Number
    },
    owner: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    images: [{ type: String }],
    location: {
        city: String,
        state: String,
        district: String
    },
    specifications: {
        brand: String,
        model: String,
        year: Number,
        horsepower: String,
        condition: {
            type: String,
            enum: ['new', 'excellent', 'good', 'fair'],
            default: 'good'
        },
        features: [String]
    },
    availability: {
        type: String,
        enum: ['available', 'rented', 'maintenance', 'unavailable'],
        default: 'available'
    },
    bookings: [{
        renter: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        startDate: Date,
        endDate: Date,
        totalPrice: Number,
        status: {
            type: String,
            enum: ['confirmed', 'completed', 'cancelled'],
            default: 'confirmed'
        },
        createdAt: { type: Date, default: Date.now }
    }]
}, { timestamps: true });

module.exports = mongoose.model('Equipment', equipmentSchema);
