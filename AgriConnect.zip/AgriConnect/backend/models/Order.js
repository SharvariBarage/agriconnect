/**
 * Order Model
 * Tracks orders placed by buyers
 */

const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    orderNumber: {
        type: String,
        unique: true
    },
    buyer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    seller: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    items: [{
        productType: { type: String, enum: ['crop', 'fertilizer'] },
        productId: { type: mongoose.Schema.Types.ObjectId, refPath: 'items.productType' },
        title: String,
        quantity: Number,
        price: Number,
        unit: String
    }],
    deliveryAddress: {
        street: String,
        city: String,
        state: String,
        pincode: String
    },
    totalAmount: {
        type: Number,
        required: true,
        min: [0, 'Total cannot be negative']
    },
    status: {
        type: String,
        enum: ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'completed'],
        default: 'pending'
    },
    paymentMethod: {
        type: String,
        enum: ['cod', 'upi', 'bank_transfer', 'wallet'],
        default: 'cod'
    },
    paymentStatus: {
        type: String,
        enum: ['pending', 'paid', 'failed', 'refunded'],
        default: 'pending'
    },
    trackingInfo: {
        courierName: String,
        trackingNumber: String,
        estimatedDelivery: Date
    },
    notes: {
        buyer: String,
        seller: String
    }
}, { timestamps: true });

// Auto-generate order number before saving
orderSchema.pre('save', function(next) {
    if (!this.orderNumber) {
        const timestamp = Date.now().toString(36).toUpperCase();
        const random = Math.random().toString(36).substring(2, 6).toUpperCase();
        this.orderNumber = `AGR-${timestamp}-${random}`;
    }
    next();
});

module.exports = mongoose.model('Order', orderSchema);
