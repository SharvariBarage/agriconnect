/**
 * Fertilizer Model
 * For fertilizers, seeds, and pesticides store
 */

const mongoose = require('mongoose');

const fertilizerSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Product name is required'],
        trim: true
    },
    type: {
        type: String,
        required: true,
        enum: ['fertilizer', 'seed', 'pesticide', 'herbicide', 'fungicide', 'organic', 'micronutrient']
    },
    category: {
        type: String,
        required: true
    },
    description: {
        type: String,
        trim: true
    },
    price: {
        type: Number,
        required: true,
        min: [0, 'Price cannot be negative']
    },
    unit: {
        type: String,
        enum: ['kg', 'liter', 'packet', 'bottle', 'bag', 'piece'],
        default: 'kg'
    },
    quantity: {
        type: Number,
        required: true,
        min: [0, 'Quantity cannot be negative']
    },
    supplier: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    images: [{ type: String }],
    specifications: {
        brand: String,
        composition: String,
        weight: String,
        usage: String,
        cropTypes: [String]
    },
    ratings: [{
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        rating: Number,
        review: String,
        date: { type: Date, default: Date.now }
    }],
    averageRating: { type: Number, default: 0 },
    inStock: {
        type: Boolean,
        default: true
    }
}, { timestamps: true });

module.exports = mongoose.model('Fertilizer', fertilizerSchema);
