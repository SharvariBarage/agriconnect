/**
 * Crop Model
 * Represents crop listings by farmers
 */

const mongoose = require('mongoose');

const cropSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Crop title is required'],
        trim: true
    },
    category: {
        type: String,
        required: [true, 'Category is required'],
        enum: ['grains', 'vegetables', 'fruits', 'pulses', 'oilseeds', 'spices', 'others']
    },
    description: {
        type: String,
        trim: true,
        maxlength: [2000, 'Description cannot exceed 2000 characters']
    },
    price: {
        type: Number,
        required: [true, 'Price is required'],
        min: [0, 'Price cannot be negative']
    },
    unit: {
        type: String,
        enum: ['kg', 'quintal', 'ton', 'piece', 'dozen'],
        default: 'kg'
    },
    quantity: {
        type: Number,
        required: [true, 'Quantity is required'],
        min: [0, 'Quantity cannot be negative']
    },
    availableQuantity: {
        type: Number,
        min: [0, 'Available quantity cannot be negative']
    },
    location: {
        city: String,
        state: String,
        district: String,
        pincode: String,
        coordinates: {
            lat: Number,
            lng: Number
        }
    },
    farmer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    images: [{
        type: String
    }],
    harvestDate: {
        type: Date
    },
    quality: {
        type: String,
        enum: ['premium', 'standard', 'economy'],
        default: 'standard'
    },
    isOrganic: {
        type: Boolean,
        default: false
    },
    status: {
        type: String,
        enum: ['available', 'sold', 'reserved', 'unavailable'],
        default: 'available'
    },
    inquiries: [{
        buyer: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        message: String,
        date: {
            type: Date,
            default: Date.now
        },
        status: {
            type: String,
            enum: ['pending', 'accepted', 'rejected'],
            default: 'pending'
        }
    }],
    ratings: [{
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        rating: Number,
        review: String,
        date: { type: Date, default: Date.now }
    }],
    averageRating: {
        type: Number,
        default: 0
    }
}, { timestamps: true });

// Indexes for search performance
cropSchema.index({ category: 1, status: 1 });
cropSchema.index({ 'location.state': 1, 'location.city': 1 });
cropSchema.index({ price: 1 });
cropSchema.index({ farmer: 1 });

module.exports = mongoose.model('Crop', cropSchema);
