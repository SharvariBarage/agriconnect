/**
 * Weather Controller
 * Fetches weather data from OpenWeather API
 * API key is stored securely in environment variables
 */

const fetch = require('node-fetch');

// OpenWeather API base URL
const BASE_URL = 'https://api.openweathermap.org/data/2.5';
const API_KEY = process.env.OPENWEATHER_API_KEY;

// Cache to reduce API calls
const weatherCache = new Map();
const CACHE_DURATION = 10 * 60 * 1000; // 10 minutes

/**
 * @desc    Get current weather for a location
 * @route   GET /api/weather/current?city=Delhi&state=DL
 */
exports.getCurrentWeather = async (req, res) => {
    try {
        const { city, lat, lon } = req.query;

        let url;
        if (lat && lon) {
            url = `${BASE_URL}/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`;
        } else if (city) {
            url = `${BASE_URL}/weather?q=${city}&appid=${API_KEY}&units=metric`;
        } else {
            // Default to Delhi
            url = `${BASE_URL}/weather?q=Delhi&appid=${API_KEY}&units=metric`;
        }

        // Check cache
        if (weatherCache.has(url) && Date.now() - weatherCache.get(url).timestamp < CACHE_DURATION) {
            return res.json(weatherCache.get(url).data);
        }

        const response = await fetch(url);
        if (!response.ok) {
            if (response.status === 404) {
                return res.status(404).json({ error: 'Location not found' });
            }
            throw new Error('Weather API request failed');
        }

        const data = await response.json();

        // Cache the result
        weatherCache.set(url, { data, timestamp: Date.now() });

        res.json({
            success: true,
            weather: {
                city: data.name,
                country: data.sys.country,
                coordinates: { lat: data.coord.lat, lon: data.coord.lon },
                temperature: data.main.temp,
                feelsLike: data.main.feels_like,
                humidity: data.main.humidity,
                pressure: data.main.pressure,
                windSpeed: data.wind.speed,
                windDirection: data.wind.deg,
                visibility: data.visibility,
                description: data.weather[0].description,
                icon: data.weather[0].icon,
                main: data.weather[0].main,
                cloudiness: data.clouds.all,
                sunrise: data.sys.sunrise,
                sunset: data.sys.sunset,
                timestamp: data.dt
            }
        });
    } catch (error) {
        console.error('Weather fetch error:', error);
        res.status(500).json({ error: 'Failed to fetch weather data' });
    }
};

/**
 * @desc    Get 7-day weather forecast
 * @route   GET /api/weather/forecast?city=Delhi
 */
exports.getForecast = async (req, res) => {
    try {
        const { city, lat, lon } = req.query;

        let url;
        if (lat && lon) {
            url = `${BASE_URL}/forecast?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`;
        } else if (city) {
            url = `${BASE_URL}/forecast?q=${city}&appid=${API_KEY}&units=metric`;
        } else {
            url = `${BASE_URL}/forecast?q=Delhi&appid=${API_KEY}&units=metric`;
        }

        const cacheKey = `forecast_${url}`;
        if (weatherCache.has(cacheKey) && Date.now() - weatherCache.get(cacheKey).timestamp < CACHE_DURATION) {
            return res.json(weatherCache.get(cacheKey).data);
        }

        const response = await fetch(url);
        if (!response.ok) throw new Error('Forecast API request failed');

        const data = await response.json();

        // Process forecast data into daily summaries
        const dailyForecast = {};
        data.list.forEach(item => {
            const date = item.dt_txt.split(' ')[0];
            if (!dailyForecast[date]) {
                dailyForecast[date] = {
                    date,
                    temps: [],
                    humidities: [],
                    windSpeeds: [],
                    descriptions: [],
                    icons: [],
                    pop: 0 // probability of precipitation
                };
            }
            dailyForecast[date].temps.push(item.main.temp);
            dailyForecast[date].humidities.push(item.main.humidity);
            dailyForecast[date].windSpeeds.push(item.wind.speed);
            dailyForecast[date].descriptions.push(item.weather[0].description);
            dailyForecast[date].icons.push(item.weather[0].icon);
            if (item.pop) {
                dailyForecast[date].pop = Math.max(dailyForecast[date].pop, item.pop);
            }
        });

        // Calculate daily summaries
        const forecast = Object.values(dailyForecast).map(day => ({
            date: day.date,
            minTemp: Math.min(...day.temps),
            maxTemp: Math.max(...day.temps),
            avgTemp: Math.round(day.temps.reduce((a, b) => a + b, 0) / day.temps.length * 10) / 10,
            avgHumidity: Math.round(day.humidities.reduce((a, b) => a + b, 0) / day.humidities.length),
            avgWindSpeed: Math.round(day.windSpeeds.reduce((a, b) => a + b, 0) / day.windSpeeds.length * 10) / 10,
            description: day.descriptions[Math.floor(day.descriptions.length / 2)],
            icon: day.icons[Math.floor(day.icons.length / 2)],
            rainProbability: Math.round(day.pop * 100)
        }));

        const result = {
            success: true,
            city: data.city.name,
            country: data.city.country,
            forecast: forecast.slice(0, 7) // 7-day forecast
        };

        weatherCache.set(cacheKey, { data: result, timestamp: Date.now() });
        res.json(result);
    } catch (error) {
        console.error('Forecast error:', error);
        res.status(500).json({ error: 'Failed to fetch forecast' });
    }
};
