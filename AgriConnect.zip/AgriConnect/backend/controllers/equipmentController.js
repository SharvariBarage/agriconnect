/**
 * Equipment Controller
 * Handles equipment rental listing and bookings
 */

const Equipment = require('../models/Equipment');

/**
 * @desc    List new equipment for rent
 * @route   POST /api/equipment
 */
exports.createEquipment = async (req, res) => {
    try {
        const { title, category, description, pricePerDay, pricePerHour, location, specifications } = req.body;

        if (!title || !category || !pricePerDay) {
            return res.status(400).json({ error: 'Title, category, and price per day are required' });
        }

        const images = req.files ? req.files.map(file => `/uploads/equipment/${file.filename}`) : [];

        const equipment = await Equipment.create({
            title,
            category,
            description,
            pricePerDay,
            pricePerHour,
            owner: req.user._id,
            location: location || {},
            specifications: specifications || {},
            images
        });

        await equipment.populate('owner', 'name profileImage');
        res.status(201).json({ success: true, message: 'Equipment listed successfully', equipment });
    } catch (error) {
        console.error('Create equipment error:', error);
        res.status(500).json({ error: 'Failed to list equipment' });
    }
};

/**
 * @desc    Get all equipment with filters
 * @route   GET /api/equipment
 */
exports.getEquipment = async (req, res) => {
    try {
        const { category, state, city, minPrice, maxPrice, availability, page = 1, limit = 12 } = req.query;

        const filter = {};

        if (category) filter.category = category;
        if (state) filter['location.state'] = { $regex: state, $options: 'i' };
        if (city) filter['location.city'] = { $regex: city, $options: 'i' };
        if (minPrice) filter.pricePerDay = { ...filter.pricePerDay, $gte: Number(minPrice) };
        if (maxPrice) filter.pricePerDay = { ...filter.pricePerDay, $lte: Number(maxPrice) };
        if (availability) filter.availability = availability;

        const skip = (parseInt(page) - 1) * parseInt(limit);

        const [equipment, total] = await Promise.all([
            Equipment.find(filter)
                .populate('owner', 'name profileImage phone')
                .sort('-createdAt')
                .skip(skip)
                .limit(parseInt(limit)),
            Equipment.countDocuments(filter)
        ]);

        res.json({
            success: true,
            equipment,
            pagination: { total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)), limit: parseInt(limit) }
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch equipment' });
    }
};

/**
 * @desc    Get single equipment
 * @route   GET /api/equipment/:id
 */
exports.getEquipmentById = async (req, res) => {
    try {
        const equipment = await Equipment.findById(req.params.id)
            .populate('owner', 'name email phone profileImage address');

        if (!equipment) {
            return res.status(404).json({ error: 'Equipment not found' });
        }

        res.json({ success: true, equipment });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch equipment' });
    }
};

/**
 * @desc    Book equipment for rent
 * @route   POST /api/equipment/:id/book
 */
exports.bookEquipment = async (req, res) => {
    try {
        const { startDate, endDate } = req.body;

        if (!startDate || !endDate) {
            return res.status(400).json({ error: 'Start date and end date are required' });
        }

        const equipment = await Equipment.findById(req.params.id);
        if (!equipment) {
            return res.status(404).json({ error: 'Equipment not found' });
        }

        if (equipment.availability !== 'available') {
            return res.status(400).json({ error: 'Equipment is not available for booking' });
        }

        // Check for overlapping bookings
        const overlapping = equipment.bookings.some(booking => {
            return booking.status === 'confirmed' && 
                   new Date(booking.startDate) < new Date(endDate) && 
                   new Date(booking.endDate) > new Date(startDate);
        });

        if (overlapping) {
            return res.status(400).json({ error: 'Equipment is already booked for these dates' });
        }

        // Calculate total price
        const start = new Date(startDate);
        const end = new Date(endDate);
        const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
        const totalPrice = days * equipment.pricePerDay;

        // Add booking
        equipment.bookings.push({
            renter: req.user._id,
            startDate: start,
            endDate: end,
            totalPrice,
            status: 'confirmed'
        });

        await equipment.save();

        res.json({
            success: true,
            message: 'Equipment booked successfully',
            booking: {
                startDate: start,
                endDate: end,
                totalPrice,
                days,
                equipment: equipment.title
            }
        });
    } catch (error) {
        console.error('Booking error:', error);
        res.status(500).json({ error: 'Failed to book equipment' });
    }
};

/**
 * @desc    Get user's booking history
 * @route   GET /api/equipment/bookings
 */
exports.getBookings = async (req, res) => {
    try {
        // Get bookings where user is renter
        const asRenter = await Equipment.find({
            'bookings.renter': req.user._id
        }).select('title category pricePerDay bookings images')
          .populate('bookings.renter', 'name');

        // Get bookings where user is owner
        const asOwner = await Equipment.find({
            owner: req.user._id
        }).select('title category pricePerDay bookings images')
          .populate('bookings.renter', 'name email phone');

        res.json({
            success: true,
            myBookings: asRenter,
            myEquipment: asOwner
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch bookings' });
    }
};

/**
 * @desc    Delete equipment listing
 * @route   DELETE /api/equipment/:id
 */
exports.deleteEquipment = async (req, res) => {
    try {
        const equipment = await Equipment.findById(req.params.id);
        if (!equipment) return res.status(404).json({ error: 'Equipment not found' });
        if (equipment.owner.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Not authorized' });
        }
        await Equipment.findByIdAndDelete(req.params.id);
        res.json({ success: true, message: 'Equipment listing deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete equipment' });
    }
};
