/**
 * Crop Controller
 * Handles CRUD operations for crop listings
 */

const Crop = require('../models/Crop');
const User = require('../models/User');

/**
 * @desc    Create a new crop listing
 * @route   POST /api/crops
 */
exports.createCrop = async (req, res) => {
    try {
        const { title, category, description, price, unit, quantity, location, harvestDate, quality, isOrganic } = req.body;

        if (!title || !category || !price || !quantity) {
            return res.status(400).json({ error: 'Title, category, price, and quantity are required' });
        }

        // Handle uploaded images
        const images = req.files ? req.files.map(file => `/uploads/crops/${file.filename}`) : [];

        const crop = await Crop.create({
            title,
            category,
            description,
            price,
            unit: unit || 'kg',
            quantity,
            availableQuantity: quantity,
            location: location || {},
            harvestDate: harvestDate || new Date(),
            quality: quality || 'standard',
            isOrganic: isOrganic || false,
            farmer: req.user._id,
            images
        });

        // Populate farmer details
        await crop.populate('farmer', 'name farmDetails profileImage');

        res.status(201).json({ success: true, message: 'Crop listing created successfully', crop });
    } catch (error) {
        console.error('Create crop error:', error);
        res.status(500).json({ error: 'Failed to create crop listing' });
    }
};

/**
 * @desc    Get all crops with filtering
 * @route   GET /api/crops
 */
exports.getCrops = async (req, res) => {
    try {
        const { category, state, city, minPrice, maxPrice, quality, isOrganic, search, page = 1, limit = 12, sortBy = '-createdAt' } = req.query;

        // Build filter
        const filter = { status: 'available' };

        if (category) filter.category = category;
        if (state) filter['location.state'] = { $regex: state, $options: 'i' };
        if (city) filter['location.city'] = { $regex: city, $options: 'i' };
        if (minPrice || maxPrice) {
            filter.price = {};
            if (minPrice) filter.price.$gte = Number(minPrice);
            if (maxPrice) filter.price.$lte = Number(maxPrice);
        }
        if (quality) filter.quality = quality;
        if (isOrganic === 'true') filter.isOrganic = true;
        if (search) {
            filter.$or = [
                { title: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } }
            ];
        }

        // Pagination
        const skip = (parseInt(page) - 1) * parseInt(limit);

        const [crops, total] = await Promise.all([
            Crop.find(filter)
                .populate('farmer', 'name profileImage farmDetails')
                .sort(sortBy)
                .skip(skip)
                .limit(parseInt(limit)),
            Crop.countDocuments(filter)
        ]);

        res.json({
            success: true,
            crops,
            pagination: {
                total,
                page: parseInt(page),
                pages: Math.ceil(total / parseInt(limit)),
                limit: parseInt(limit)
            }
        });
    } catch (error) {
        console.error('Get crops error:', error);
        res.status(500).json({ error: 'Failed to fetch crops' });
    }
};

/**
 * @desc    Get a single crop by ID
 * @route   GET /api/crops/:id
 */
exports.getCropById = async (req, res) => {
    try {
        const crop = await Crop.findById(req.params.id)
            .populate('farmer', 'name email phone address farmDetails profileImage ratings totalSales');

        if (!crop) {
            return res.status(404).json({ error: 'Crop not found' });
        }

        res.json({ success: true, crop });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch crop' });
    }
};

/**
 * @desc    Update a crop listing
 * @route   PUT /api/crops/:id
 */
exports.updateCrop = async (req, res) => {
    try {
        const crop = await Crop.findById(req.params.id);

        if (!crop) {
            return res.status(404).json({ error: 'Crop not found' });
        }

        // Check ownership
        if (crop.farmer.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Not authorized to update this listing' });
        }

        // Update fields
        const allowedFields = ['title', 'category', 'description', 'price', 'unit', 'quantity', 'availableQuantity', 'location', 'harvestDate', 'quality', 'isOrganic', 'status'];
        allowedFields.forEach(field => {
            if (req.body[field] !== undefined) {
                crop[field] = req.body[field];
            }
        });

        // Handle new images
        if (req.files && req.files.length > 0) {
            crop.images = req.files.map(file => `/uploads/crops/${file.filename}`);
        }

        await crop.save();
        await crop.populate('farmer', 'name profileImage');

        res.json({ success: true, message: 'Crop listing updated successfully', crop });
    } catch (error) {
        console.error('Update crop error:', error);
        res.status(500).json({ error: 'Failed to update crop' });
    }
};

/**
 * @desc    Delete a crop listing
 * @route   DELETE /api/crops/:id
 */
exports.deleteCrop = async (req, res) => {
    try {
        const crop = await Crop.findById(req.params.id);

        if (!crop) {
            return res.status(404).json({ error: 'Crop not found' });
        }

        if (crop.farmer.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Not authorized to delete this listing' });
        }

        await Crop.findByIdAndDelete(req.params.id);
        res.json({ success: true, message: 'Crop listing deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete crop' });
    }
};

/**
 * @desc    Submit a buyer inquiry on a crop
 * @route   POST /api/crops/:id/inquiry
 */
exports.submitInquiry = async (req, res) => {
    try {
        const crop = await Crop.findById(req.params.id);

        if (!crop) {
            return res.status(404).json({ error: 'Crop not found' });
        }

        if (crop.farmer.toString() === req.user._id.toString()) {
            return res.status(400).json({ error: 'Cannot inquire on your own listing' });
        }

        crop.inquiries.push({
            buyer: req.user._id,
            message: req.body.message || 'I am interested in this crop listing.',
            date: new Date(),
            status: 'pending'
        });

        await crop.save();
        res.json({ success: true, message: 'Inquiry submitted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to submit inquiry' });
    }
};

/**
 * @desc    Get inquiries for farmer's crops
 * @route   GET /api/crops/inquiries
 */
exports.getInquiries = async (req, res) => {
    try {
        const crops = await Crop.find({ farmer: req.user._id })
            .select('title category price images inquiries')
            .populate('inquiries.buyer', 'name email phone profileImage');

        // Collect all inquiries with crop info
        const allInquiries = [];
        crops.forEach(crop => {
            crop.inquiries.forEach(inquiry => {
                if (inquiry.buyer) {
                    allInquiries.push({
                        inquiry,
                        crop: {
                            id: crop._id,
                            title: crop.title,
                            category: crop.category,
                            price: crop.price,
                            images: crop.images
                        }
                    });
                }
            });
        });

        res.json({ success: true, inquiries: allInquiries });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch inquiries' });
    }
};
