/**
 * Dashboard Controller
 * Provides dashboard data for farmers and buyers
 */

const Crop = require('../models/Crop');
const Order = require('../models/Order');
const Equipment = require('../models/Equipment');
const Cart = require('../models/Cart');

/**
 * @desc    Get farmer dashboard data
 * @route   GET /api/dashboard/farmer
 */
exports.farmerDashboard = async (req, res) => {
    try {
        const userId = req.user._id;

        const [
            totalListings,
            activeListings,
            soldListings,
            totalInquiries,
            recentOrders,
            recentCrops
        ] = await Promise.all([
            Crop.countDocuments({ farmer: userId }),
            Crop.countDocuments({ farmer: userId, status: 'available' }),
            Crop.countDocuments({ farmer: userId, status: 'sold' }),
            Crop.aggregate([
                { $match: { farmer: userId } },
                { $unwind: '$inquiries' },
                { $count: 'totalInquiries' }
            ]),
            Order.find({ seller: userId }).sort('-createdAt').limit(5)
                .populate('buyer', 'name email'),
            Crop.find({ farmer: userId }).sort('-createdAt').limit(5)
        ]);

        // Calculate earnings
        const completedOrders = await Order.find({
            seller: userId,
            status: { $in: ['delivered', 'completed'] }
        });
        const totalEarnings = completedOrders.reduce((sum, order) => sum + order.totalAmount, 0);

        // Recent inquiries
        const cropsWithInquiries = await Crop.find({ farmer: userId, 'inquiries.0': { $exists: true } })
            .select('title inquiries')
            .populate('inquiries.buyer', 'name email');

        res.json({
            success: true,
            dashboard: {
                stats: {
                    totalListings,
                    activeListings,
                    soldListings,
                    totalInquiries: totalInquiries[0]?.totalInquiries || 0,
                    totalEarnings,
                    completedOrders: completedOrders.length
                },
                recentOrders,
                recentCrops,
                recentInquiries: cropsWithInquiries
            }
        });
    } catch (error) {
        console.error('Farmer dashboard error:', error);
        res.status(500).json({ error: 'Failed to fetch dashboard data' });
    }
};

/**
 * @desc    Get buyer dashboard data
 * @route   GET /api/dashboard/buyer
 */
exports.buyerDashboard = async (req, res) => {
    try {
        const userId = req.user._id;

        const [
            cartItems,
            recentOrders,
            totalSpent,
            pendingOrders
        ] = await Promise.all([
            Cart.findOne({ user: userId }),
            Order.find({ buyer: userId }).sort('-createdAt').limit(5)
                .populate('seller', 'name profileImage'),
            Order.find({ buyer: userId, status: { $in: ['delivered', 'completed'] } }),
            Order.countDocuments({ buyer: userId, status: 'pending' })
        ]);

        const totalSpentAmount = totalSpent.reduce((sum, order) => sum + order.totalAmount, 0);

        // Order status breakdown
        const statusCounts = await Order.aggregate([
            { $match: { buyer: userId } },
            { $group: { _id: '$status', count: { $sum: 1 } } }
        ]);

        res.json({
            success: true,
            dashboard: {
                stats: {
                    cartItems: cartItems?.items?.length || 0,
                    cartTotal: cartItems?.items?.reduce((sum, item) => sum + (item.price * item.quantity), 0) || 0,
                    totalOrders: totalSpent.length,
                    totalSpent: totalSpentAmount,
                    pendingOrders
                },
                recentOrders,
                orderStatuses: statusCounts
            }
        });
    } catch (error) {
        console.error('Buyer dashboard error:', error);
        res.status(500).json({ error: 'Failed to fetch dashboard data' });
    }
};
