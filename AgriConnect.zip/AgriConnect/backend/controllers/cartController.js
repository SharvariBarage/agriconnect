/**
 * Cart Controller
 * Shopping cart operations for buyers
 */

const Cart = require('../models/Cart');
const Crop = require('../models/Crop');
const Fertilizer = require('../models/Fertilizer');

/**
 * @desc    Get user's cart
 * @route   GET /api/cart
 */
exports.getCart = async (req, res) => {
    try {
        let cart = await Cart.findOne({ user: req.user._id })
            .populate('items.productId', 'title name price images unit category type quantity availableQuantity');

        if (!cart) {
            cart = { items: [], user: req.user._id };
        }

        const total = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        res.json({ success: true, cart: cart.items || [], total });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch cart' });
    }
};

/**
 * @desc    Add item to cart
 * @route   POST /api/cart
 */
exports.addToCart = async (req, res) => {
    try {
        const { productType, productId, quantity } = req.body;

        if (!productType || !productId || !quantity) {
            return res.status(400).json({ error: 'Product type, product ID, and quantity are required' });
        }

        // Validate product exists
        let product;
        let price;
        if (productType === 'crop') {
            product = await Crop.findById(productId);
            price = product?.price;
        } else if (productType === 'fertilizer') {
            product = await Fertilizer.findById(productId);
            price = product?.price;
        } else {
            return res.status(400).json({ error: 'Invalid product type' });
        }

        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }

        // Find or create cart
        let cart = await Cart.findOne({ user: req.user._id });
        if (!cart) {
            cart = await Cart.create({ user: req.user._id, items: [] });
        }

        // Check if item already in cart
        const existingIndex = cart.items.findIndex(
            item => item.productId.toString() === productId && item.productType === productType
        );

        if (existingIndex > -1) {
            cart.items[existingIndex].quantity += quantity;
        } else {
            cart.items.push({
                productType,
                productId,
                quantity,
                price
            });
        }

        await cart.save();

        const total = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        res.json({ success: true, message: 'Item added to cart', cart: cart.items, total });
    } catch (error) {
        console.error('Add to cart error:', error);
        res.status(500).json({ error: 'Failed to add item to cart' });
    }
};

/**
 * @desc    Update cart item quantity
 * @route   PUT /api/cart/:productId
 */
exports.updateCartItem = async (req, res) => {
    try {
        const { quantity } = req.body;
        const { productId } = req.params;

        if (!quantity || quantity < 1) {
            return res.status(400).json({ error: 'Invalid quantity' });
        }

        const cart = await Cart.findOne({ user: req.user._id });
        if (!cart) return res.status(404).json({ error: 'Cart not found' });

        const item = cart.items.find(item => item.productId.toString() === productId);
        if (!item) return res.status(404).json({ error: 'Item not found in cart' });

        item.quantity = quantity;
        await cart.save();

        const total = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        res.json({ success: true, message: 'Cart updated', cart: cart.items, total });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update cart' });
    }
};

/**
 * @desc    Remove item from cart
 * @route   DELETE /api/cart/:productId
 */
exports.removeFromCart = async (req, res) => {
    try {
        const { productId } = req.params;

        const cart = await Cart.findOne({ user: req.user._id });
        if (!cart) return res.status(404).json({ error: 'Cart not found' });

        cart.items = cart.items.filter(item => item.productId.toString() !== productId);
        await cart.save();

        const total = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        res.json({ success: true, message: 'Item removed', cart: cart.items, total });
    } catch (error) {
        res.status(500).json({ error: 'Failed to remove item' });
    }
};

/**
 * @desc    Clear entire cart
 * @route   DELETE /api/cart
 */
exports.clearCart = async (req, res) => {
    try {
        await Cart.findOneAndUpdate({ user: req.user._id }, { $set: { items: [] } });
        res.json({ success: true, message: 'Cart cleared' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to clear cart' });
    }
};
