/**
 * Fertilizer Controller
 * Handles fertilizer/seed/pesticide store operations
 */

const Fertilizer = require('../models/Fertilizer');

/**
 * @desc    Add new product to store
 * @route   POST /api/fertilizers
 */
exports.createProduct = async (req, res) => {
    try {
        const { name, type, category, description, price, unit, quantity, specifications } = req.body;

        if (!name || !type || !price || !quantity) {
            return res.status(400).json({ error: 'Name, type, price, and quantity are required' });
        }

        const images = req.files ? req.files.map(file => `/uploads/fertilizers/${file.filename}`) : [];

        const product = await Fertilizer.create({
            name, type, category: category || type,
            description, price, unit: unit || 'kg', quantity,
            supplier: req.user._id,
            specifications: specifications || {},
            images
        });

        await product.populate('supplier', 'name profileImage');
        res.status(201).json({ success: true, message: 'Product added successfully', product });
    } catch (error) {
        console.error('Create product error:', error);
        res.status(500).json({ error: 'Failed to add product' });
    }
};

/**
 * @desc    Get all products with filters
 * @route   GET /api/fertilizers
 */
exports.getProducts = async (req, res) => {
    try {
        const { type, category, minPrice, maxPrice, inStock, search, page = 1, limit = 12 } = req.query;

        const filter = {};
        if (type) filter.type = type;
        if (category) filter.category = { $regex: category, $options: 'i' };
        if (minPrice || maxPrice) {
            filter.price = {};
            if (minPrice) filter.price.$gte = Number(minPrice);
            if (maxPrice) filter.price.$lte = Number(maxPrice);
        }
        if (inStock === 'true') filter.inStock = true;
        if (search) {
            filter.$or = [
                { name: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } }
            ];
        }

        const skip = (parseInt(page) - 1) * parseInt(limit);

        const [products, total] = await Promise.all([
            Fertilizer.find(filter)
                .populate('supplier', 'name profileImage')
                .sort('-createdAt')
                .skip(skip)
                .limit(parseInt(limit)),
            Fertilizer.countDocuments(filter)
        ]);

        res.json({
            success: true, products,
            pagination: { total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)), limit: parseInt(limit) }
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch products' });
    }
};

/**
 * @desc    Get single product
 * @route   GET /api/fertilizers/:id
 */
exports.getProductById = async (req, res) => {
    try {
        const product = await Fertilizer.findById(req.params.id)
            .populate('supplier', 'name email phone profileImage');

        if (!product) return res.status(404).json({ error: 'Product not found' });
        res.json({ success: true, product });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch product' });
    }
};

/**
 * @desc    Update product
 * @route   PUT /api/fertilizers/:id
 */
exports.updateProduct = async (req, res) => {
    try {
        const product = await Fertilizer.findById(req.params.id);
        if (!product) return res.status(404).json({ error: 'Product not found' });
        if (product.supplier.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Not authorized' });
        }

        const allowedFields = ['name', 'type', 'category', 'description', 'price', 'unit', 'quantity', 'specifications', 'inStock'];
        allowedFields.forEach(field => {
            if (req.body[field] !== undefined) product[field] = req.body[field];
        });

        if (req.files && req.files.length > 0) {
            product.images = req.files.map(file => `/uploads/fertilizers/${file.filename}`);
        }

        await product.save();
        res.json({ success: true, message: 'Product updated', product });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update product' });
    }
};

/**
 * @desc    Delete product
 * @route   DELETE /api/fertilizers/:id
 */
exports.deleteProduct = async (req, res) => {
    try {
        const product = await Fertilizer.findById(req.params.id);
        if (!product) return res.status(404).json({ error: 'Product not found' });
        if (product.supplier.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Not authorized' });
        }
        await Fertilizer.findByIdAndDelete(req.params.id);
        res.json({ success: true, message: 'Product deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete product' });
    }
};
