/**
 * AI Assistant Controller
 * Securely connects to Gemini/OpenAI API for agricultural advice
 * API keys are stored in environment variables - NEVER exposed to frontend
 */

const fetch = require('node-fetch');

// System prompt for the AI assistant
const SYSTEM_PROMPT = `You are "AgriBot", a knowledgeable agricultural assistant for AgriConnect - a Smart Agriculture Marketplace.

Your expertise includes:
1. Crop Recommendations - Suggesting suitable crops based on season, soil, climate, and region
2. Disease Prevention - Identifying plant diseases and suggesting prevention/treatment methods
3. Fertilizer Suggestions - Recommending appropriate fertilizers based on crop type and soil condition
4. Irrigation Advice - Suggesting optimal watering schedules and irrigation methods
5. Government Schemes - Information about PM-KISAN, Kisan Credit Card, crop insurance, subsidies
6. Weather Advice - How weather conditions affect crops and farming decisions
7. Market Trends - General advice on when to sell/buy crops
8. Organic Farming - Tips on transitioning to and maintaining organic farming

Guidelines:
- Always provide practical, actionable advice
- Consider the Indian agricultural context
- Be specific about timing, quantities, and methods
- Mention relevant government schemes when applicable
- Warn about potential risks
- Keep responses concise but informative
- Use simple language that farmers can understand
- Format responses with clear sections using markdown`;

/**
 * @desc    Chat with AI assistant
 * @route   POST /api/ai/chat
 * @access  Protected
 */
exports.chat = async (req, res) => {
    try {
        const { message, conversation } = req.body;

        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        // Try Gemini first, fallback to OpenAI
        let response;
        try {
            response = await callGeminiAPI(message, conversation);
        } catch (geminiError) {
            console.log('Gemini failed, trying OpenAI...');
            try {
                response = await callOpenAI(message, conversation);
            } catch (openAIError) {
                return res.status(500).json({ 
                    error: 'AI service temporarily unavailable',
                    fallback: 'Please try again later. You can also browse our knowledge base.'
                });
            }
        }

        res.json({ success: true, response });
    } catch (error) {
        console.error('AI Chat error:', error);
        res.status(500).json({ error: 'Failed to process request' });
    }
};

/**
 * @desc    Get quick suggestions/topics
 * @route   GET /api/ai/suggestions
 */
exports.getSuggestions = async (req, res) => {
    try {
        const suggestions = [
            { topic: 'Crop Recommendations', query: 'What crops should I grow this season in North India?' },
            { topic: 'Disease Prevention', query: 'How to prevent blight in tomato crops?' },
            { topic: 'Fertilizer Guide', query: 'What fertilizers are best for wheat cultivation?' },
            { topic: 'Irrigation Tips', query: 'Best irrigation methods for small farms?' },
            { topic: 'Government Schemes', query: 'What government schemes are available for farmers?' },
            { topic: 'Organic Farming', query: 'How to start organic farming?' },
            { topic: 'Weather Advice', query: 'How does rainfall pattern affect crop selection?' },
            { topic: 'Pest Control', query: 'Natural ways to control pests without chemicals?' }
        ];
        res.json({ success: true, suggestions });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch suggestions' });
    }
};

/**
 * Call Gemini API
 */
async function callGeminiAPI(message, conversation = []) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error('Gemini API key not configured');

    // Build conversation history
    const contents = [];
    
    // Add system instruction
    contents.push({
        role: 'user',
        parts: [{ text: `${SYSTEM_PROMPT}\n\n---\n\nMy question: ${message}` }]
    });

    // Add conversation history
    conversation.slice(-10).forEach(msg => {
        contents.push({
            role: msg.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: msg.content }]
        });
    });

    const response = await fetch(
        `https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents,
                generationConfig: {
                    temperature: 0.7,
                    maxOutputTokens: 1024,
                    topP: 0.95,
                    topK: 40
                },
                safetySettings: [
                    { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
                    { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_MEDIUM_AND_ABOVE' }
                ]
            })
        }
    );

    if (!response.ok) throw new Error('Gemini API request failed');

    const data = await response.json();
    return data.candidates[0]?.content?.parts[0]?.text || 'Sorry, I could not generate a response.';
}

/**
 * Call OpenAI API
 */
async function callOpenAI(message, conversation = []) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) throw new Error('OpenAI API key not configured');

    const messages = [
        { role: 'system', content: SYSTEM_PROMPT },
        ...conversation.slice(-10).map(msg => ({
            role: msg.role === 'assistant' ? 'assistant' : 'user',
            content: msg.content
        })),
        { role: 'user', content: message }
    ];

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages,
            max_tokens: 1024,
            temperature: 0.7
        })
    });

    if (!response.ok) throw new Error('OpenAI API request failed');

    const data = await response.json();
    return data.choices[0]?.message?.content || 'Sorry, I could not generate a response.';
}
