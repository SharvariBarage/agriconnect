/**
 * Order Controller
 * Handles order placement and tracking
 */

const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Crop = require('../models/Crop');
const Fertilizer = require('../models/Fertilizer');

/**
 * @desc    Place an order from cart
 * @route   POST /api/orders
 */
exports.placeOrder = async (req, res) => {
    try {
        const { deliveryAddress, paymentMethod, notes } = req.body;

        // Get user's cart
        const cart = await Cart.findOne({ user: req.user._id }).populate('items.productId');
        if (!cart || cart.items.length === 0) {
            return res.status(400).json({ error: 'Cart is empty' });
        }

        // Group items by seller
        const itemsBySeller = {};
        let totalAmount = 0;

        for (const item of cart.items) {
            const product = item.productId;
            if (!product) continue;

            let sellerId;
            let title;
            let unit;

            if (item.productType === 'crop') {
                sellerId = product.farmer;
                title = product.title;
                unit = product.unit;
            } else {
                sellerId = product.supplier;
                title = product.name;
                unit = product.unit;
            }

            if (!sellerId) continue;

            const itemTotal = item.price * item.quantity;
            totalAmount += itemTotal;

            if (!itemsBySeller[sellerId]) {
                itemsBySeller[sellerId] = [];
            }
            itemsBySeller[sellerId].push({
                productType: item.productType,
                productId: product._id,
                title,
                quantity: item.quantity,
                price: item.price,
                unit
            });
        }

        // Create orders for each seller
        const orders = [];
        for (const [sellerId, items] of Object.entries(itemsBySeller)) {
            const orderTotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

            const order = await Order.create({
                buyer: req.user._id,
                seller: sellerId,
                items,
                deliveryAddress: deliveryAddress || {},
                totalAmount: orderTotal,
                paymentMethod: paymentMethod || 'cod',
                paymentStatus: paymentMethod === 'cod' ? 'pending' : 'paid',
                notes: notes || ''
            });

            orders.push(order);

            // Update available quantity
            for (const item of items) {
                if (item.productType === 'crop') {
                    await Crop.findByIdAndUpdate(item.productId, {
                        $inc: { availableQuantity: -item.quantity }
                    });
                }
            }
        }

        // Clear cart
        await Cart.findOneAndUpdate(
            { user: req.user._id },
            { $set: { items: [] } }
        );

        res.status(201).json({
            success: true,
            message: 'Order placed successfully',
            orders
        });
    } catch (error) {
        console.error('Place order error:', error);
        res.status(500).json({ error: 'Failed to place order' });
    }
};

/**
 * @desc    Get user's orders
 * @route   GET /api/orders
 */
exports.getOrders = async (req, res) => {
    try {
        const { status } = req.query;
        const filter = {};

        if (req.user.role === 'buyer') {
            filter.buyer = req.user._id;
        } else {
            filter.seller = req.user._id;
        }
        if (status) filter.status = status;

        const orders = await Order.find(filter)
            .sort('-createdAt')
            .populate('buyer', 'name email phone address')
            .populate('seller', 'name email phone profileImage');

        res.json({ success: true, orders });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
};

/**
 * @desc    Get single order
 * @route   GET /api/orders/:id
 */
exports.getOrderById = async (req, res) => {
    try {
        const order = await Order.findById(req.params.id)
            .populate('buyer', 'name email phone address')
            .populate('seller', 'name email phone profileImage');

        if (!order) return res.status(404).json({ error: 'Order not found' });

        // Check authorization
        if (order.buyer._id.toString() !== req.user._id.toString() &&
            order.seller._id.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Not authorized' });
        }

        res.json({ success: true, order });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch order' });
    }
};

/**
 * @desc    Update order status
 * @route   PUT /api/orders/:id/status
 */
exports.updateOrderStatus = async (req, res) => {
    try {
        const { status, trackingInfo, notes } = req.body;
        const order = await Order.findById(req.params.id);

        if (!order) return res.status(404).json({ error: 'Order not found' });

        // Only seller can update status
        if (order.seller.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Only seller can update order status' });
        }

        const validStatuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'completed'];
        if (status && !validStatuses.includes(status)) {
            return res.status(400).json({ error: 'Invalid status' });
        }

        if (status) order.status = status;
        if (trackingInfo) order.trackingInfo = { ...order.trackingInfo, ...trackingInfo };
        if (notes) order.notes.seller = notes;

        await order.save();
        res.json({ success: true, message: 'Order updated', order });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update order' });
    }
};

/**
 * @desc    Cancel order (buyer)
 * @route   PUT /api/orders/:id/cancel
 */
exports.cancelOrder = async (req, res) => {
    try {
        const order = await Order.findById(req.params.id);
        if (!order) return res.status(404).json({ error: 'Order not found' });
        if (order.buyer.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Not authorized' });
        }
        if (['shipped', 'delivered', 'completed'].includes(order.status)) {
            return res.status(400).json({ error: 'Cannot cancel order at this stage' });
        }

        order.status = 'cancelled';
        order.paymentStatus = 'refunded';
        await order.save();
        res.json({ success: true, message: 'Order cancelled', order });
    } catch (error) {
        res.status(500).json({ error: 'Failed to cancel order' });
    }
};
