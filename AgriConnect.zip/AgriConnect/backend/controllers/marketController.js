/**
 * Market Prices Controller
 * Provides crop market prices with trends
 * Uses a simulated API with realistic Indian mandi prices
 * In production, connect to AGMARKNET API (https://agmarknet.gov.in/)
 */

/**
 * Sample market price data (simulated for demo)
 * In production, replace with actual AGMARKNET API integration
 */
const cropPriceData = {
    'rice': [
        { date: '2026-07-18', minPrice: 2800, maxPrice: 3200, modalPrice: 3000, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-19', minPrice: 2850, maxPrice: 3250, modalPrice: 3050, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-20', minPrice: 2900, maxPrice: 3300, modalPrice: 3100, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-21', minPrice: 2880, maxPrice: 3280, modalPrice: 3080, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-22', minPrice: 2920, maxPrice: 3320, modalPrice: 3120, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-23', minPrice: 2950, maxPrice: 3350, modalPrice: 3150, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-24', minPrice: 2980, maxPrice: 3380, modalPrice: 3180, market: 'Delhi', unit: 'quintal' }
    ],
    'wheat': [
        { date: '2026-07-18', minPrice: 2200, maxPrice: 2600, modalPrice: 2400, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-19', minPrice: 2250, maxPrice: 2650, modalPrice: 2450, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-20', minPrice: 2280, maxPrice: 2680, modalPrice: 2480, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-21', minPrice: 2300, maxPrice: 2700, modalPrice: 2500, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-22', minPrice: 2320, maxPrice: 2720, modalPrice: 2520, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-23', minPrice: 2350, maxPrice: 2750, modalPrice: 2550, market: 'Delhi', unit: 'quintal' },
        { date: '2026-07-24', minPrice: 2380, maxPrice: 2780, modalPrice: 2580, market: 'Delhi', unit: 'quintal' }
    ],
    'tomato': [
        { date: '2026-07-18', minPrice: 800, maxPrice: 1200, modalPrice: 1000, market: 'Mumbai', unit: 'quintal' },
        { date: '2026-07-19', minPrice: 850, maxPrice: 1250, modalPrice: 1050, market: 'Mumbai', unit: 'quintal' },
        { date: '2026-07-20', minPrice: 900, maxPrice: 1300, modalPrice: 1100, market: 'Mumbai', unit: 'quintal' },
        { date: '2026-07-21', minPrice: 920, maxPrice: 1320, modalPrice: 1120, market: 'Mumbai', unit: 'quintal' },
        { date: '2026-07-22', minPrice: 880, maxPrice: 1280, modalPrice: 1080, market: 'Mumbai', unit: 'quintal' },
        { date: '2026-07-23', minPrice: 860, maxPrice: 1260, modalPrice: 1060, market: 'Mumbai', unit: 'quintal' },
        { date: '2026-07-24', minPrice: 840, maxPrice: 1240, modalPrice: 1040, market: 'Mumbai', unit: 'quintal' }
    ],
    'potato': [
        { date: '2026-07-18', minPrice: 600, maxPrice: 900, modalPrice: 750, market: 'Agra', unit: 'quintal' },
        { date: '2026-07-19', minPrice: 620, maxPrice: 920, modalPrice: 770, market: 'Agra', unit: 'quintal' },
        { date: '2026-07-20', minPrice: 640, maxPrice: 940, modalPrice: 790, market: 'Agra', unit: 'quintal' },
        { date: '2026-07-21', minPrice: 630, maxPrice: 930, modalPrice: 780, market: 'Agra', unit: 'quintal' },
        { date: '2026-07-22', minPrice: 650, maxPrice: 950, modalPrice: 800, market: 'Agra', unit: 'quintal' },
        { date: '2026-07-23', minPrice: 660, maxPrice: 960, modalPrice: 810, market: 'Agra', unit: 'quintal' },
        { date: '2026-07-24', minPrice: 670, maxPrice: 970, modalPrice: 820, market: 'Agra', unit: 'quintal' }
    ],
    'onion': [
        { date: '2026-07-18', minPrice: 1200, maxPrice: 1800, modalPrice: 1500, market: 'Nashik', unit: 'quintal' },
        { date: '2026-07-19', minPrice: 1250, maxPrice: 1850, modalPrice: 1550, market: 'Nashik', unit: 'quintal' },
        { date: '2026-07-20', minPrice: 1300, maxPrice: 1900, modalPrice: 1600, market: 'Nashik', unit: 'quintal' },
        { date: '2026-07-21', minPrice: 1280, maxPrice: 1880, modalPrice: 1580, market: 'Nashik', unit: 'quintal' },
        { date: '2026-07-22', minPrice: 1320, maxPrice: 1920, modalPrice: 1620, market: 'Nashik', unit: 'quintal' },
        { date: '2026-07-23', minPrice: 1350, maxPrice: 1950, modalPrice: 1650, market: 'Nashik', unit: 'quintal' },
        { date: '2026-07-24', minPrice: 1380, maxPrice: 1980, modalPrice: 1680, market: 'Nashik', unit: 'quintal' }
    ],
    'cotton': [
        { date: '2026-07-18', minPrice: 5500, maxPrice: 6500, modalPrice: 6000, market: 'Nagpur', unit: 'quintal' },
        { date: '2026-07-19', minPrice: 5550, maxPrice: 6550, modalPrice: 6050, market: 'Nagpur', unit: 'quintal' },
        { date: '2026-07-20', minPrice: 5600, maxPrice: 6600, modalPrice: 6100, market: 'Nagpur', unit: 'quintal' },
        { date: '2026-07-21', minPrice: 5580, maxPrice: 6580, modalPrice: 6080, market: 'Nagpur', unit: 'quintal' },
        { date: '2026-07-22', minPrice: 5620, maxPrice: 6620, modalPrice: 6120, market: 'Nagpur', unit: 'quintal' },
        { date: '2026-07-23', minPrice: 5650, maxPrice: 6650, modalPrice: 6150, market: 'Nagpur', unit: 'quintal' },
        { date: '2026-07-24', minPrice: 5680, maxPrice: 6680, modalPrice: 6180, market: 'Nagpur', unit: 'quintal' }
    ],
    'sugarcane': [
        { date: '2026-07-18', minPrice: 310, maxPrice: 380, modalPrice: 345, market: 'Lucknow', unit: 'quintal' },
        { date: '2026-07-19', minPrice: 315, maxPrice: 385, modalPrice: 350, market: 'Lucknow', unit: 'quintal' },
        { date: '2026-07-20', minPrice: 320, maxPrice: 390, modalPrice: 355, market: 'Lucknow', unit: 'quintal' },
        { date: '2026-07-21', minPrice: 318, maxPrice: 388, modalPrice: 353, market: 'Lucknow', unit: 'quintal' },
        { date: '2026-07-22', minPrice: 322, maxPrice: 392, modalPrice: 357, market: 'Lucknow', unit: 'quintal' },
        { date: '2026-07-23', minPrice: 325, maxPrice: 395, modalPrice: 360, market: 'Lucknow', unit: 'quintal' },
        { date: '2026-07-24', minPrice: 328, maxPrice: 398, modalPrice: 363, market: 'Lucknow', unit: 'quintal' }
    ],
    'maize': [
        { date: '2026-07-18', minPrice: 1800, maxPrice: 2200, modalPrice: 2000, market: 'Bangalore', unit: 'quintal' },
        { date: '2026-07-19', minPrice: 1820, maxPrice: 2220, modalPrice: 2020, market: 'Bangalore', unit: 'quintal' },
        { date: '2026-07-20', minPrice: 1850, maxPrice: 2250, modalPrice: 2050, market: 'Bangalore', unit: 'quintal' },
        { date: '2026-07-21', minPrice: 1830, maxPrice: 2230, modalPrice: 2030, market: 'Bangalore', unit: 'quintal' },
        { date: '2026-07-22', minPrice: 1860, maxPrice: 2260, modalPrice: 2060, market: 'Bangalore', unit: 'quintal' },
        { date: '2026-07-23', minPrice: 1880, maxPrice: 2280, modalPrice: 2080, market: 'Bangalore', unit: 'quintal' },
        { date: '2026-07-24', minPrice: 1900, maxPrice: 2300, modalPrice: 2100, market: 'Bangalore', unit: 'quintal' }
    ]
};

// Available crops list
const availableCrops = Object.keys(cropPriceData);

/**
 * @desc    Get current market prices
 * @route   GET /api/market/prices
 */
exports.getPrices = async (req, res) => {
    try {
        const { crop, market, days = 7 } = req.query;

        if (crop && !cropPriceData[crop.toLowerCase()]) {
            return res.status(404).json({ 
                error: 'Crop not found', 
                available: availableCrops 
            });
        }

        let result;
        if (crop) {
            const cropData = cropPriceData[crop.toLowerCase()];
            result = {
                crop: crop.toLowerCase(),
                prices: cropData.slice(-parseInt(days)),
                latest: cropData[cropData.length - 1],
                trend: calculateTrend(cropData)
            };
        } else {
            // Return latest prices for all crops
            result = availableCrops.map(crop => {
                const data = cropPriceData[crop];
                return {
                    crop,
                    latest: data[data.length - 1],
                    trend: calculateTrend(data)
                };
            });
        }

        res.json({ success: true, data: result, lastUpdated: new Date().toISOString() });
    } catch (error) {
        console.error('Market prices error:', error);
        res.status(500).json({ error: 'Failed to fetch market prices' });
    }
};

/**
 * @desc    Get price trends for a crop
 * @route   GET /api/market/trends?crop=rice
 */
exports.getTrends = async (req, res) => {
    try {
        const { crop } = req.query;

        if (!crop || !cropPriceData[crop.toLowerCase()]) {
            return res.status(404).json({ error: 'Crop data not available' });
        }

        const data = cropPriceData[crop.toLowerCase()];
        const trend = calculateTrend(data);

        res.json({
            success: true,
            crop: crop.toLowerCase(),
            trend,
            historical: data
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch trends' });
    }
};

/**
 * @desc    Search crops by name
 * @route   GET /api/market/search?q=rice
 */
exports.searchCrops = async (req, res) => {
    try {
        const { q } = req.query;
        if (!q) return res.status(400).json({ error: 'Search query required' });

        const results = availableCrops.filter(crop => 
            crop.toLowerCase().includes(q.toLowerCase())
        );

        const data = results.map(crop => {
            const priceData = cropPriceData[crop];
            const latest = priceData[priceData.length - 1];
            return {
                crop,
                latest,
                trend: calculateTrend(priceData)
            };
        });

        res.json({ success: true, results: data });
    } catch (error) {
        res.status(500).json({ error: 'Search failed' });
    }
};

// Helper: Calculate price trend
function calculateTrend(data) {
    if (data.length < 2) return { change: 0, direction: 'stable', percentage: 0 };
    
    const first = data[0].modalPrice;
    const last = data[data.length - 1].modalPrice;
    const change = last - first;
    const percentage = ((change / first) * 100).toFixed(2);
    const direction = change > 0 ? 'up' : change < 0 ? 'down' : 'stable';

    return { change, direction, percentage, first, last };
}
