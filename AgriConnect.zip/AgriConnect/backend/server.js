/**
 * AgriConnect - Smart Agriculture Marketplace
 * Main Server Entry Point
 * 
 * Features:
 * - Farmer/Buyer Registration & Authentication
 * - Crop Marketplace
 * - Equipment Rental
 * - Fertilizer Store
 * - Weather Dashboard
 * - Market Prices
 * - AI Assistant
 */

// Load environment variables
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

// Import routes
const authRoutes = require('./routes/auth');
const cropRoutes = require('./routes/crops');
const equipmentRoutes = require('./routes/equipment');
const fertilizerRoutes = require('./routes/fertilizers');
const weatherRoutes = require('./routes/weather');
const marketRoutes = require('./routes/market');
const aiRoutes = require('./routes/ai');
const orderRoutes = require('./routes/orders');
const cartRoutes = require('./routes/cart');
const dashboardRoutes = require('./routes/dashboard');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 5000;

// Security Middleware
app.use(helmet());

// Rate Limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// CORS Configuration
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true
}));

// Body Parsing Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static Files - Serve frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// Upload directory as static
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/crops', cropRoutes);
app.use('/api/equipment', equipmentRoutes);
app.use('/api/fertilizers', fertilizerRoutes);
app.use('/api/weather', weatherRoutes);
app.use('/api/market', marketRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Health Check
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        service: 'AgriConnect API'
    });
});

// Serve frontend for all non-API routes
app.get('*', (req, res) => {
    if (req.url.startsWith('/api')) {
        return res.status(404).json({ error: 'API endpoint not found' });
    }
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Global Error Handler
app.use((err, req, res, next) => {
    console.error('Server Error:', err.stack);
    res.status(500).json({ 
        error: 'Internal Server Error',
        message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
    });
});

// Connect to MongoDB and start server
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/agriconnect')
    .then(() => {
        console.log('✅ MongoDB Connected Successfully');
        app.listen(PORT, () => {
            console.log(`🚀 AgriConnect Server running on port ${PORT}`);
            console.log(`📡 API: http://localhost:${PORT}/api`);
            console.log(`🌐 Frontend: http://localhost:${PORT}`);
        });
    })
    .catch((error) => {
        console.error('❌ MongoDB Connection Failed:', error.message);
        console.log('⚠️  Starting server without database connection...');
        app.listen(PORT, () => {
            console.log(`🚀 AgriConnect Server running on port ${PORT} (No DB)`);
        });
    });

module.exports = app;
