# AgriConnect – Smart Agriculture Marketplace

A modern, full-stack agriculture marketplace web application connecting farmers, buyers, and suppliers across India. Built with **Node.js + Express** backend, **MongoDB** database, and **vanilla HTML/CSS/JavaScript** frontend.

---

## Features

### For Farmers
- Register/Login with role-based access
- Create and manage crop listings with images, quantity, price, and location
- Edit/Delete listings
- View buyer inquiries
- Dashboard with earnings and sales analytics

### For Buyers
- Browse and search crops with advanced filters
- Filter by category, price, quality, location, and organic status
- Add products to shopping cart
- Place orders with delivery tracking
- View purchase history and order status

### Equipment Rental
- List tractors, harvesters, pumps, sprayers, and more
- Rent equipment by date with booking confirmation
- View rental history and availability

### Fertilizer Store
- Browse fertilizers, seeds, pesticides, and organic products
- Search and filter by type, price, and availability
- Add to cart and checkout

### Weather Dashboard
- Real-time weather using OpenWeather API
- 7-day weather forecast
- Temperature, humidity, wind speed, rain probability

### Market Prices
- Live crop prices from major mandis
- Interactive price trend charts (Chart.js)
- Search by crop name

### AI Farming Assistant
- Powered by Gemini/OpenAI API (server-side, API keys never exposed)
- Crop recommendations
- Disease prevention advice
- Fertilizer suggestions
- Irrigation guidance
- Government schemes information
- Weather-based farming advice

### Additional Features
- Dark/Light mode toggle
- Fully responsive design (mobile-first)
- Modern CSS animations
- JWT-based authentication
- Input validation and error handling
- Image upload support
- Toast notifications

---

## Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Frontend    | HTML5, CSS3 (Custom), JavaScript ES6+ |
| Backend     | Node.js, Express.js                 |
| Database    | MongoDB (via Mongoose ODM)          |
| Charts      | Chart.js                            |
| Icons       | Font Awesome 6                      |
| Fonts       | Google Fonts (Inter)                |
| AI          | Google Gemini / OpenAI GPT          |
| Weather     | OpenWeather API                     |
| Auth        | JWT (jsonwebtoken)                  |
| Uploads     | Multer                              |
| Security    | Helmet, CORS, Rate Limiting, bcryptjs |

---

## Project Structure

```
AgriConnect/
│
├── frontend/
│   ├── index.html          # Main SPA with all pages
│   ├── css/
│   │   └── style.css       # Complete stylesheet with dark/light mode
│   ├── js/
│   │   └── app.js          # Frontend application logic
│   └── assets/             # Static assets (images, etc.)
│
├── backend/
│   ├── server.js           # Express server entry point
│   ├── routes/             # API route definitions
│   │   ├── auth.js
│   │   ├── crops.js
│   │   ├── equipment.js
│   │   ├── fertilizers.js
│   │   ├── weather.js
│   │   ├── market.js
│   │   ├── ai.js
│   │   ├── orders.js
│   │   ├── cart.js
│   │   └── dashboard.js
│   ├── controllers/        # Business logic handlers
│   │   ├── authController.js
│   │   ├── cropController.js
│   │   ├── equipmentController.js
│   │   ├── fertilizerController.js
│   │   ├── weatherController.js
│   │   ├── marketController.js
│   │   ├── aiController.js
│   │   ├── orderController.js
│   │   ├── cartController.js
│   │   └── dashboardController.js
│   ├── models/             # MongoDB schemas
│   │   ├── User.js
│   │   ├── Crop.js
│   │   ├── Equipment.js
│   │   ├── Fertilizer.js
│   │   ├── Cart.js
│   │   └── Order.js
│   ├── middleware/         # Custom middleware
│   │   ├── auth.js         # JWT authentication
│   │   └── upload.js       # Multer file upload
│   ├── uploads/            # Uploaded files storage
│   ├── .env.example        # Environment variables template
│   └── package.json        # Backend dependencies
│
└── README.md               # This file
```

---

## Getting Started

### Prerequisites

- **Node.js** v16 or higher
- **MongoDB** v5+ (local or MongoDB Atlas)
- **npm** or **pnpm**

### Installation

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd AgriConnect
   ```

2. **Install backend dependencies:**
   ```bash
   cd backend
   npm install
   ```

3. **Set up environment variables:**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` with your values:
   ```env
   PORT=5000
   NODE_ENV=development
   MONGODB_URI=mongodb://localhost:27017/agriconnect
   JWT_SECRET=your_super_secret_key_here
   JWT_EXPIRE=7d
   OPENWEATHER_API_KEY=your_openweathermap_key
   GEMINI_API_KEY=your_gemini_api_key
   OPENAI_API_KEY=your_openai_api_key
   FRONTEND_URL=http://localhost:5000
   ```

4. **Start MongoDB:**
   ```bash
   # If running locally
   mongod
   ```
   
   Or use MongoDB Atlas (update `MONGODB_URI` in `.env`).

5. **Run the application:**
   ```bash
   npm start
   ```
   
   For development with auto-reload:
   ```bash
   npm run dev
   ```

6. **Access the application:**
   - Frontend: `http://localhost:5000`
   - API: `http://localhost:5000/api`
   - Health check: `http://localhost:5000/api/health`

---

## API Endpoints

### Authentication
| Method | Endpoint              | Description         | Auth |
|--------|-----------------------|---------------------|------|
| POST   | `/api/auth/register`  | Register new user   | No   |
| POST   | `/api/auth/login`     | Login user          | No   |
| GET    | `/api/auth/me`        | Get current profile | Yes  |
| PUT    | `/api/auth/profile`   | Update profile      | Yes  |

### Crops
| Method | Endpoint                  | Description         | Auth |
|--------|---------------------------|---------------------|------|
| GET    | `/api/crops`              | List all crops      | No   |
| GET    | `/api/crops/:id`          | Get crop details    | No   |
| POST   | `/api/crops`              | Create listing      | Yes  |
| PUT    | `/api/crops/:id`          | Update listing      | Yes  |
| DELETE | `/api/crops/:id`          | Delete listing      | Yes  |
| POST   | `/api/crops/:id/inquiry`  | Submit inquiry      | Yes  |

### Equipment
| Method | Endpoint                    | Description      | Auth |
|--------|-----------------------------|------------------|------|
| GET    | `/api/equipment`            | List equipment   | No   |
| GET    | `/api/equipment/:id`        | Get details      | No   |
| POST   | `/api/equipment`            | List equipment   | Yes  |
| POST   | `/api/equipment/:id/book`   | Book equipment   | Yes  |
| DELETE | `/api/equipment/:id`        | Delete listing   | Yes  |

### Fertilizers
| Method | Endpoint               | Description    | Auth |
|--------|------------------------|----------------|------|
| GET    | `/api/fertilizers`     | List products  | No   |
| GET    | `/api/fertilizers/:id` | Get details    | No   |
| POST   | `/api/fertilizers`     | Add product    | Yes  |
| PUT    | `/api/fertilizers/:id` | Update product | Yes  |

### Weather
| Method | Endpoint                | Description     | Auth |
|--------|-------------------------|-----------------|------|
| GET    | `/api/weather/current`  | Current weather | No   |
| GET    | `/api/weather/forecast` | 7-day forecast  | No   |

### Market Prices
| Method | Endpoint           | Description      | Auth |
|--------|--------------------|------------------|------|
| GET    | `/api/market/prices` | Get all prices   | No   |
| GET    | `/api/market/trends` | Price trends     | No   |
| GET    | `/api/market/search` | Search crops     | No   |

### AI Chat
| Method | Endpoint          | Description       | Auth |
|--------|-------------------|-------------------|------|
| GET    | `/api/ai/suggestions` | Get topics     | No   |
| POST   | `/api/ai/chat`    | Chat with AI      | Yes  |

### Orders & Cart
| Method | Endpoint          | Description         | Auth |
|--------|-------------------|---------------------|------|
| GET    | `/api/cart`       | Get cart            | Yes  |
| POST   | `/api/cart`       | Add to cart         | Yes  |
| DELETE | `/api/cart/:id`   | Remove from cart    | Yes  |
| GET    | `/api/orders`     | Get orders          | Yes  |
| POST   | `/api/orders`     | Place order         | Yes  |

### Dashboard
| Method | Endpoint                | Description      | Auth |
|--------|-------------------------|------------------|------|
| GET    | `/api/dashboard/farmer` | Farmer dashboard | Yes  |
| GET    | `/api/dashboard/buyer`  | Buyer dashboard  | Yes  |

---

## Deployment on AWS EC2

### Step 1: Launch an EC2 Instance

1. Go to AWS Console → EC2 → Launch Instance
2. Choose **Ubuntu 22.04 LTS** (t2.medium recommended)
3. Configure security group with these rules:

| Type        | Protocol | Port | Source  |
|-------------|----------|------|---------|
| SSH         | TCP      | 22   | Your IP |
| HTTP        | TCP      | 80   | 0.0.0.0/0 |
| HTTPS       | TCP      | 443  | 0.0.0.0/0 |
| Custom TCP  | TCP      | 5000 | 0.0.0.0/0 |

4. Create/download your key pair (`.pem` file)

### Step 2: Connect to Your Instance

```bash
chmod 400 your-key.pem
ssh -i your-key.pem ubuntu@<your-ec2-public-ip>
```

### Step 3: Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install MongoDB
sudo apt install gnupg
wget -qO - https://www.mongodb.org/static/pgp/server-7.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt update
sudo apt install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod
```

### Step 4: Deploy the Application

```bash
# Clone your repository
git clone <repository-url>
cd AgriConnect/backend

# Install dependencies
npm install

# Create .env file
nano .env
# Add your configuration (use production values)
```

### Step 5: Install PM2 (Process Manager)

```bash
sudo npm install -g pm2

# Start the application
pm2 start server.js --name agriconnect

# Save PM2 process list
pm2 save
pm2 startup systemd
```

### Step 6: Install and Configure Nginx (Reverse Proxy)

```bash
sudo apt install -y nginx

# Create Nginx config
sudo nano /etc/nginx/sites-available/agriconnect
```

Add the following configuration:

```nginx
server {
    listen 80;
    server_name your-domain.com; # Replace with your domain or EC2 public IP

    # Frontend static files
    location / {
        root /home/ubuntu/AgriConnect/frontend;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # API proxy
    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }

    # Uploaded files
    location /uploads/ {
        proxy_pass http://localhost:5000;
    }
}
```

```bash
# Enable the site
sudo ln -s /etc/nginx/sites-available/agriconnect /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Step 7: Configure Firewall

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

### Step 8: (Optional) Set Up SSL with Let's Encrypt

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### Step 9: PM2 Commands

```bash
pm2 list          # View running processes
pm2 logs agriconnect  # View application logs
pm2 restart agriconnect # Restart application
pm2 stop agriconnect    # Stop application
```

---

## Environment Variables

| Variable              | Description                          | Required |
|-----------------------|--------------------------------------|----------|
| `PORT`                | Server port (default: 5000)          | No       |
| `NODE_ENV`            | Environment (development/production) | No       |
| `MONGODB_URI`         | MongoDB connection string            | Yes      |
| `JWT_SECRET`          | Secret key for JWT tokens            | Yes      |
| `JWT_EXPIRE`          | Token expiration (e.g., 7d)          | No       |
| `OPENWEATHER_API_KEY` | OpenWeather API key                  | For weather |
| `GEMINI_API_KEY`      | Google Gemini API key                | For AI   |
| `OPENAI_API_KEY`      | OpenAI API key (fallback for AI)     | For AI   |
| `FRONTEND_URL`        | Frontend origin URL (for CORS)       | No       |
| `MAX_FILE_SIZE`       | Max upload size in bytes             | No       |

---

## Getting API Keys

### OpenWeather API
1. Visit [https://openweathermap.org/api](https://openweathermap.org/api)
2. Sign up for a free account
3. Generate an API key from the dashboard
4. Add to `.env`: `OPENWEATHER_API_KEY=your_key`

### Google Gemini API
1. Visit [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
2. Click "Create API Key"
3. Add to `.env`: `GEMINI_API_KEY=your_key`

### OpenAI API (Alternative)
1. Visit [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Create a new API key
3. Add to `.env`: `OPENAI_API_KEY=your_key`

---

## Project Scripts

| Command       | Description                    |
|---------------|--------------------------------|
| `npm start`   | Start production server        |
| `npm run dev` | Start with auto-reload (dev)   |

---

## License

MIT License. Built with ❤ for Indian Farmers.

---

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-feature`)
3. Commit changes (`git commit -m 'Add new feature'`)
4. Push to the branch (`git push origin feature/new-feature`)
5. Open a Pull Request

---

## Support

For issues and support, please open an issue on GitHub or contact support@agriconnect.in.
