/**
 * AgriConnect – Smart Agriculture Marketplace
 * Frontend Application JavaScript
 * 
 * Features: SPA navigation, auth, CRUD, chat, weather, charts
 */

// ============================================
// CONFIGURATION
// ============================================
const API_URL = window.location.origin + '/api';
const state = {
    user: null,
    token: localStorage.getItem('token') || null,
    currentPage: 'home',
    cartCount: 0,
    cropsPage: 1,
    equipmentPage: 1,
    fertilizersPage: 1,
    priceChart: null,
    chatHistory: []
};

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initTheme();
    initAuth();
    initChat();
    initWeather();
    initMarketPrices();
    initFilters();
    loadFeaturedCrops();
    loadUser();
});

// ============================================
// NAVIGATION (SPA)
// ============================================
function initNavigation() {
    document.querySelectorAll('.nav-link, [data-page]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.dataset.page;
            if (page) navigateTo(page);
        });
    });

    // Mobile nav toggle
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');
    navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navLinks.classList.toggle('active');
    });

    // User dropdown
    const userAvatar = document.getElementById('userAvatar');
    const userDropdown = document.getElementById('userDropdown');
    if (userAvatar) {
        userAvatar.addEventListener('click', (e) => {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });
    }
    document.addEventListener('click', () => {
        if (userDropdown) userDropdown.classList.remove('show');
    });
}

function navigateTo(page) {
    // Check auth for protected pages
    const protectedPages = ['dashboard', 'profile', 'orders', 'ai-chat'];
    if (protectedPages.includes(page) && !state.user) {
        showToast('Please login to access this page', 'info');
        page = 'login';
    }

    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    
    // Show target page
    const targetPage = document.getElementById(`page-${page}`);
    if (targetPage) {
        targetPage.classList.add('active');
    } else {
        document.getElementById('page-home').classList.add('active');
    }

    // Update active nav link
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    const activeLink = document.querySelector(`.nav-link[data-page="${page}"]`);
    if (activeLink) activeLink.classList.add('active');

    // Close mobile nav
    document.getElementById('navLinks').classList.remove('active');
    document.getElementById('navToggle').classList.remove('active');

    // Page-specific initialization
    state.currentPage = page;
    switch(page) {
        case 'marketplace': loadCrops(); break;
        case 'equipment': loadEquipment(); break;
        case 'fertilizers': loadFertilizers(); break;
        case 'weather': loadWeather(); break;
        case 'market-prices': loadMarketPrices(); break;
        case 'dashboard': loadDashboard(); break;
        case 'profile': loadProfile(); break;
        case 'orders': loadOrders(); break;
        case 'ai-chat': loadAISuggestions(); break;
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ============================================
// THEME (Dark/Light Mode)
// ============================================
function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    document.getElementById('themeToggle').addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('theme', next);
        updateThemeIcon(next);
    });
}

function updateThemeIcon(theme) {
    const icon = document.querySelector('#themeToggle i');
    icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
}

// ============================================
// AUTHENTICATION
// ============================================
function initAuth() {
    // Tab switching
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const target = tab.dataset.tab;
            document.getElementById('loginForm').classList.toggle('hidden', target !== 'login');
            document.getElementById('registerForm').classList.toggle('hidden', target !== 'register');
        });
    });

    // Login form
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        await login(email, password);
    });

    // Register form
    document.getElementById('registerForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = {
            name: document.getElementById('regName').value,
            email: document.getElementById('regEmail').value,
            password: document.getElementById('regPassword').value,
            phone: document.getElementById('regPhone').value,
            role: document.getElementById('regRole').value
        };
        await register(data);
    });

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', (e) => {
        e.preventDefault();
        logout();
    });
}

async function login(email, password) {
    try {
        const res = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();

        if (!res.ok) {
            showMessage('loginMessage', data.error, 'error');
            return;
        }

        state.token = data.token;
        state.user = data.user;
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));

        showMessage('loginMessage', 'Login successful!', 'success');
        setTimeout(() => {
            updateAuthUI();
            navigateTo('dashboard');
            showToast('Welcome back, ' + data.user.name + '!', 'success');
        }, 500);
    } catch (error) {
        showMessage('loginMessage', 'Network error. Please try again.', 'error');
    }
}

async function register(data) {
    try {
        const res = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const result = await res.json();

        if (!res.ok) {
            showMessage('registerMessage', result.error, 'error');
            return;
        }

        state.token = result.token;
        state.user = result.user;
        localStorage.setItem('token', result.token);
        localStorage.setItem('user', JSON.stringify(result.user));

        showMessage('registerMessage', 'Registration successful!', 'success');
        setTimeout(() => {
            updateAuthUI();
            navigateTo('dashboard');
            showToast('Welcome to AgriConnect, ' + result.user.name + '!', 'success');
        }, 500);
    } catch (error) {
        showMessage('registerMessage', 'Network error. Please try again.', 'error');
    }
}

function logout() {
    state.token = null;
    state.user = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    updateAuthUI();
    navigateTo('home');
    showToast('Logged out successfully', 'info');
}

function loadUser() {
    if (state.token && !state.user) {
        try {
            state.user = JSON.parse(localStorage.getItem('user'));
        } catch(e) {}
    }
    if (state.user) updateAuthUI();
}

function updateAuthUI() {
    const authNav = document.getElementById('navAuth');
    const userMenu = document.getElementById('userMenu');
    const cartBtn = document.getElementById('cartBtn');

    if (state.user) {
        authNav.style.display = 'none';
        userMenu.style.display = 'block';
        if (state.user.role === 'buyer') {
            cartBtn.style.display = 'flex';
        } else {
            cartBtn.style.display = 'none';
        }
    } else {
        authNav.style.display = 'block';
        userMenu.style.display = 'none';
        cartBtn.style.display = 'none';
    }
}

// ============================================
// API HELPER
// ============================================
async function apiRequest(endpoint, options = {}) {
    const headers = { ...options.headers };
    if (state.token) {
        headers['Authorization'] = `Bearer ${state.token}`;
    }
    if (options.body && !(options.body instanceof FormData)) {
        headers['Content-Type'] = 'application/json';
    }

    const res = await fetch(`${API_URL}${endpoint}`, {
        ...options,
        headers
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
}

// ============================================
// CROP MARKETPLACE
// ============================================
async function loadFeaturedCrops() {
    try {
        const data = await apiRequest('/crops?limit=4&sortBy=-createdAt');
        const container = document.getElementById('featuredCrops');
        if (data.crops && data.crops.length > 0) {
            container.innerHTML = '<div class="products-grid">' + 
                data.crops.map(crop => createCropCard(crop)).join('') + 
                '</div>';
        } else {
            container.innerHTML = '<p class="text-center">No crops listed yet. Be the first to list!</p>';
        }
    } catch (error) {
        document.getElementById('featuredCrops').innerHTML = 
            '<p class="text-center">Unable to load featured crops. Please try again later.</p>';
    }
}

async function loadCrops() {
    try {
        const params = new URLSearchParams();
        const category = document.getElementById('filterCategory').value;
        const stateFilter = document.getElementById('filterState').value;
        const minPrice = document.getElementById('filterMinPrice').value;
        const maxPrice = document.getElementById('filterMaxPrice').value;
        const quality = document.getElementById('filterQuality').value;
        const organic = document.getElementById('filterOrganic').checked;
        const search = document.getElementById('searchCrops').value;
        const sortBy = document.getElementById('sortBy').value;

        if (category) params.append('category', category);
        if (stateFilter) params.append('state', stateFilter);
        if (minPrice) params.append('minPrice', minPrice);
        if (maxPrice) params.append('maxPrice', maxPrice);
        if (quality) params.append('quality', quality);
        if (organic) params.append('isOrganic', 'true');
        if (search) params.append('search', search);
        params.append('sortBy', sortBy);
        params.append('page', state.cropsPage);
        params.append('limit', '12');

        const data = await apiRequest(`/crops?${params}`);
        const grid = document.getElementById('cropsGrid');
        
        if (data.crops && data.crops.length > 0) {
            grid.innerHTML = data.crops.map(crop => createCropCard(crop)).join('');
        } else {
            grid.innerHTML = '<p class="text-center">No crops found matching your criteria.</p>';
        }

        // Pagination
        renderPagination('cropsPagination', data.pagination, (page) => {
            state.cropsPage = page;
            loadCrops();
        });
    } catch (error) {
        document.getElementById('cropsGrid').innerHTML = 
            '<p class="text-center">Failed to load crops. Please try again.</p>';
    }
}

function createCropCard(crop) {
    const farmerName = crop.farmer?.name || 'Unknown Farmer';
    const farmerImg = crop.farmer?.profileImage || '';
    const imageHtml = crop.images && crop.images.length > 0 
        ? `<img src="${crop.images[0]}" alt="${crop.title}" loading="lazy">`
        : '<i class="fas fa-wheat-awn"></i>';
    
    const badges = [];
    if (crop.isOrganic) badges.push('<span class="product-badge badge-organic">Organic</span>');
    if (crop.quality === 'premium') badges.push('<span class="product-badge badge-premium">Premium</span>');

    return `
        <div class="product-card">
            <div class="product-image" onclick="viewCropDetail('${crop._id}')">
                ${imageHtml}
                ${badges.join('')}
            </div>
            <div class="product-info">
                <h3 class="product-title" onclick="viewCropDetail('${crop._id}')" style="cursor:pointer">${crop.title}</h3>
                <div class="product-meta">
                    <i class="fas fa-user"></i> ${farmerName}
                    <span>|</span>
                    <i class="fas fa-map-marker-alt"></i> ${crop.location?.city || crop.location?.state || 'India'}
                </div>
                <div class="product-price">₹${crop.price} <span>/${crop.unit}</span></div>
                <div class="product-meta">
                    <i class="fas fa-box"></i> ${crop.availableQuantity || crop.quantity} ${crop.unit} available
                </div>
                <div class="product-actions">
                    <button class="btn btn-outline btn-sm" onclick="addToCart('crop','${crop._id}',1,${crop.price})">
                        <i class="fas fa-cart-plus"></i> Add
                    </button>
                    <button class="btn btn-primary btn-sm" onclick="viewCropDetail('${crop._id}')">
                        <i class="fas fa-eye"></i> View
                    </button>
                </div>
            </div>
        </div>
    `;
}

async function viewCropDetail(id) {
    try {
        const data = await apiRequest(`/crops/${id}`);
        const crop = data.crop;
        
        document.getElementById('cropDetailTitle').textContent = crop.title;
        const container = document.getElementById('cropDetailContent');
        
        const imageHtml = crop.images && crop.images.length > 0
            ? `<img src="${crop.images[0]}" alt="${crop.title}" class="main-image">`
            : '<div class="image-placeholder"><i class="fas fa-wheat-awn"></i></div>';

        const farmer = crop.farmer || {};
        const badges = [];
        if (crop.isOrganic) badges.push('<span class="product-badge badge-organic">Organic</span>');
        if (crop.quality === 'premium') badges.push('<span class="product-badge badge-premium">Premium</span>');

        container.innerHTML = `
            <div class="crop-detail-images">
                ${imageHtml}
            </div>
            <div class="crop-detail-info">
                ${badges.length ? `<div style="margin-bottom:1rem">${badges.join(' ')}</div>` : ''}
                <h1>${crop.title}</h1>
                <p style="color:var(--text-secondary)">${crop.description || 'No description available'}</p>
                <div class="price-large">₹${crop.price} <span style="font-size:1rem;color:var(--text-muted)">/${crop.unit}</span></div>
                <div class="detail-row"><span class="detail-label">Category</span><span class="detail-value" style="text-transform:capitalize">${crop.category}</span></div>
                <div class="detail-row"><span class="detail-label">Quantity</span><span class="detail-value">${crop.availableQuantity || crop.quantity} ${crop.unit}</span></div>
                <div class="detail-row"><span class="detail-label">Quality</span><span class="detail-value" style="text-transform:capitalize">${crop.quality}</span></div>
                <div class="detail-row"><span class="detail-label">Location</span><span class="detail-value">${crop.location?.city || ''}, ${crop.location?.state || ''}</span></div>
                <div class="detail-row"><span class="detail-label">Harvest Date</span><span class="detail-value">${crop.harvestDate ? new Date(crop.harvestDate).toLocaleDateString() : 'N/A'}</span></div>
                <div class="detail-row"><span class="detail-label">Farmer</span><span class="detail-value">${farmer.name || 'N/A'} ${farmer.ratings ? `(${farmer.ratings}★)` : ''}</span></div>
                <div class="detail-row"><span class="detail-label">Listed</span><span class="detail-value">${new Date(crop.createdAt).toLocaleDateString()}</span></div>
                <div style="margin-top:1.5rem;display:flex;gap:1rem">
                    ${state.user && state.user.role === 'buyer' ? `
                        <button class="btn btn-primary" onclick="addToCart('crop','${crop._id}',1,${crop.price})">
                            <i class="fas fa-cart-plus"></i> Add to Cart
                        </button>
                    ` : ''}
                    ${state.user && state.user.role === 'buyer' ? `
                        <button class="btn btn-outline" onclick="submitInquiry('${crop._id}')">
                            <i class="fas fa-envelope"></i> Send Inquiry
                        </button>
                    ` : ''}
                </div>
            </div>
        `;

        navigateTo('crop-detail');
    } catch (error) {
        showToast('Failed to load crop details', 'error');
    }
}

// ============================================
// EQUIPMENT RENTAL
// ============================================
async function loadEquipment() {
    try {
        const params = new URLSearchParams();
        const type = document.getElementById('filterEquipType').value;
        const maxPrice = document.getElementById('filterEquipMaxPrice').value;
        const avail = document.getElementById('filterEquipAvail').value;

        if (type) params.append('category', type);
        if (maxPrice) params.append('maxPrice', maxPrice);
        if (avail) params.append('availability', avail);
        params.append('page', state.equipmentPage);

        const data = await apiRequest(`/equipment?${params}`);
        const grid = document.getElementById('equipmentGrid');

        if (data.equipment && data.equipment.length > 0) {
            grid.innerHTML = data.equipment.map(eq => `
                <div class="product-card">
                    <div class="product-image" onclick="viewEquipmentDetail('${eq._id}')" style="cursor:pointer">
                        ${eq.images && eq.images.length > 0 
                            ? `<img src="${eq.images[0]}" alt="${eq.title}" loading="lazy">`
                            : '<i class="fas fa-tractor"></i>'}
                        <span class="product-badge ${eq.availability === 'available' ? 'badge-organic' : ''}">${eq.availability}</span>
                    </div>
                    <div class="product-info">
                        <h3 class="product-title">${eq.title}</h3>
                        <div class="product-meta">
                            <i class="fas fa-user"></i> ${eq.owner?.name || 'Owner'}
                            <span>|</span>
                            <i class="fas fa-map-marker-alt"></i> ${eq.location?.city || eq.location?.state || 'India'}
                        </div>
                        <div class="product-price">₹${eq.pricePerDay} <span>/day</span></div>
                        ${eq.specifications?.brand ? `<div class="product-meta">${eq.specifications.brand} ${eq.specifications.model || ''}</div>` : ''}
                        <div class="product-actions">
                            <button class="btn btn-primary btn-sm" onclick="viewEquipmentDetail('${eq._id}')">
                                <i class="fas fa-eye"></i> View & Book
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        } else {
            grid.innerHTML = '<p class="text-center">No equipment available.</p>';
        }

        renderPagination('equipmentPagination', data.pagination, (page) => {
            state.equipmentPage = page;
            loadEquipment();
        });
    } catch (error) {
        document.getElementById('equipmentGrid').innerHTML = '<p class="text-center">Failed to load equipment.</p>';
    }
}

async function viewEquipmentDetail(id) {
    try {
        const data = await apiRequest(`/equipment/${id}`);
        const eq = data.equipment;
        
        document.getElementById('equipDetailTitle').textContent = eq.title;
        const container = document.getElementById('equipmentDetailContent');
        
        const imageHtml = eq.images && eq.images.length > 0
            ? `<img src="${eq.images[0]}" alt="${eq.title}" class="main-image">`
            : '<div class="image-placeholder"><i class="fas fa-tractor"></i></div>';

        const owner = eq.owner || {};
        const specs = eq.specifications || {};

        container.innerHTML = `
            <div class="crop-detail-images">${imageHtml}</div>
            <div class="crop-detail-info">
                <h1>${eq.title}</h1>
                <p style="color:var(--text-secondary)">${eq.description || 'No description available'}</p>
                <div class="price-large">₹${eq.pricePerDay} <span style="font-size:1rem;color:var(--text-muted)">/day</span></div>
                <span class="product-badge ${eq.availability === 'available' ? 'badge-organic' : ''}">${eq.availability}</span>
                <div class="detail-row"><span class="detail-label">Category</span><span class="detail-value" style="text-transform:capitalize">${eq.category}</span></div>
                <div class="detail-row"><span class="detail-label">Brand</span><span class="detail-value">${specs.brand || 'N/A'}</span></div>
                <div class="detail-row"><span class="detail-label">Model</span><span class="detail-value">${specs.model || 'N/A'}</span></div>
                <div class="detail-row"><span class="detail-label">Year</span><span class="detail-value">${specs.year || 'N/A'}</span></div>
                <div class="detail-row"><span class="detail-label">Condition</span><span class="detail-value" style="text-transform:capitalize">${specs.condition || 'N/A'}</span></div>
                <div class="detail-row"><span class="detail-label">Location</span><span class="detail-value">${eq.location?.city || ''}, ${eq.location?.state || ''}</span></div>
                <div class="detail-row"><span class="detail-label">Owner</span><span class="detail-value">${owner.name || 'N/A'} - ${owner.phone || 'N/A'}</span></div>
                ${eq.availability === 'available' ? `
                    <div style="margin-top:1.5rem;background:var(--bg-alt);padding:1.5rem;border-radius:var(--radius)">
                        <h3 style="margin-bottom:1rem">Book This Equipment</h3>
                        <div class="form-row" style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1rem">
                            <div>
                                <label>Start Date</label>
                                <input type="date" id="bookStartDate" class="form-control" style="width:100%;padding:0.75rem;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--bg);color:var(--text)">
                            </div>
                            <div>
                                <label>End Date</label>
                                <input type="date" id="bookEndDate" class="form-control" style="width:100%;padding:0.75rem;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--bg);color:var(--text)">
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block" onclick="bookEquipment('${eq._id}')">
                            <i class="fas fa-calendar-check"></i> Confirm Booking
                        </button>
                    </div>
                ` : '<p style="margin-top:1.5rem;color:var(--danger)"><i class="fas fa-times-circle"></i> This equipment is currently unavailable.</p>'}
            </div>
        `;

        navigateTo('equipment-detail');
    } catch (error) {
        showToast('Failed to load equipment details', 'error');
    }
}

async function bookEquipment(id) {
    const startDate = document.getElementById('bookStartDate').value;
    const endDate = document.getElementById('bookEndDate').value;

    if (!startDate || !endDate) {
        showToast('Please select start and end dates', 'error');
        return;
    }

    try {
        const data = await apiRequest(`/equipment/${id}/book`, {
            method: 'POST',
            body: JSON.stringify({ startDate, endDate })
        });
        showToast('Equipment booked successfully! Total: ₹' + data.booking.totalPrice, 'success');
    } catch (error) {
        showToast(error.message, 'error');
    }
}

// ============================================
// FERTILIZER STORE
// ============================================
async function loadFertilizers() {
    try {
        const params = new URLSearchParams();
        const type = document.getElementById('filterFertType').value;
        const minPrice = document.getElementById('filterFertMinPrice').value;
        const maxPrice = document.getElementById('filterFertMaxPrice').value;
        const inStock = document.getElementById('filterFertInStock').checked;
        const search = document.getElementById('searchFertilizers').value;

        if (type) params.append('type', type);
        if (minPrice) params.append('minPrice', minPrice);
        if (maxPrice) params.append('maxPrice', maxPrice);
        if (inStock) params.append('inStock', 'true');
        if (search) params.append('search', search);
        params.append('page', state.fertilizersPage);

        const data = await apiRequest(`/fertilizers?${params}`);
        const grid = document.getElementById('fertilizersGrid');

        if (data.products && data.products.length > 0) {
            grid.innerHTML = data.products.map(p => `
                <div class="product-card">
                    <div class="product-image">
                        ${p.images && p.images.length > 0 
                            ? `<img src="${p.images[0]}" alt="${p.name}" loading="lazy">`
                            : '<i class="fas fa-leaf"></i>'}
                        ${!p.inStock ? '<span class="product-badge" style="background:var(--danger);color:#fff">Out of Stock</span>' : ''}
                    </div>
                    <div class="product-info">
                        <h3 class="product-title">${p.name}</h3>
                        <div class="product-meta">
                            <span style="text-transform:capitalize">${p.type}</span>
                            <span>|</span>
                            <span>${p.category}</span>
                        </div>
                        <div class="product-price">₹${p.price} <span>/${p.unit}</span></div>
                        <div class="product-meta">
                            <i class="fas fa-box"></i> ${p.quantity} in stock
                        </div>
                        <div class="product-actions">
                            ${p.inStock ? `
                                <button class="btn btn-primary btn-sm" onclick="addToCart('fertilizer','${p._id}',1,${p.price})">
                                    <i class="fas fa-cart-plus"></i> Add
                                </button>
                            ` : ''}
                        </div>
                    </div>
                </div>
            `).join('');
        } else {
            grid.innerHTML = '<p class="text-center">No products found.</p>';
        }

        renderPagination('fertilizersPagination', data.pagination, (page) => {
            state.fertilizersPage = page;
            loadFertilizers();
        });
    } catch (error) {
        document.getElementById('fertilizersGrid').innerHTML = '<p class="text-center">Failed to load products.</p>';
    }
}

// ============================================
// CART
// ============================================
async function addToCart(productType, productId, quantity, price) {
    if (!state.user) {
        showToast('Please login to add items to cart', 'info');
        navigateTo('login');
        return;
    }

    try {
        await apiRequest('/cart', {
            method: 'POST',
            body: JSON.stringify({ productType, productId, quantity, price })
        });
        state.cartCount++;
        document.getElementById('cartBadge').textContent = state.cartCount;
        showToast('Item added to cart!', 'success');
    } catch (error) {
        showToast(error.message, 'error');
    }
}

async function loadCart() {
    try {
        const data = await apiRequest('/cart');
        const cartItems = data.cart || [];
        state.cartCount = cartItems.length;
        document.getElementById('cartBadge').textContent = state.cartCount;

        const container = document.getElementById('cartItems');
        if (cartItems.length === 0) {
            container.innerHTML = '<p class="text-center">Your cart is empty</p>';
            document.getElementById('cartSummary').innerHTML = '';
            return;
        }

        container.innerHTML = cartItems.map(item => `
            <div class="order-card" style="display:flex;justify-content:space-between;align-items:center">
                <div>
                    <strong>${item.productId?.title || item.productId?.name || 'Product'}</strong>
                    <span style="color:var(--text-muted);margin-left:0.5rem">x${item.quantity}</span>
                    <span style="color:var(--text-muted);margin-left:0.5rem">(${item.productType})</span>
                </div>
                <div style="display:flex;align-items:center;gap:1rem">
                    <span style="font-weight:700;color:var(--primary)">₹${(item.price * item.quantity).toFixed(2)}</span>
                    <button class="btn btn-danger btn-sm" onclick="removeFromCart('${item.productId?._id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');

        document.getElementById('cartSummary').innerHTML = `
            <div>
                <strong>Total: <span class="cart-total">₹${data.total?.toFixed(2) || '0.00'}</span></strong>
            </div>
            <button class="btn btn-primary" onclick="placeOrder()">
                <i class="fas fa-shopping-bag"></i> Place Order
            </button>
        `;
    } catch (error) {
        document.getElementById('cartItems').innerHTML = '<p class="text-center">Failed to load cart</p>';
    }
}

async function removeFromCart(productId) {
    try {
        await apiRequest(`/cart/${productId}`, { method: 'DELETE' });
        loadCart();
        showToast('Item removed from cart', 'info');
    } catch (error) {
        showToast('Failed to remove item', 'error');
    }
}

async function placeOrder() {
    if (!state.user) return;
    
    try {
        await apiRequest('/orders', {
            method: 'POST',
            body: JSON.stringify({
                deliveryAddress: state.user.address || {},
                paymentMethod: 'cod'
            })
        });
        showToast('Order placed successfully!', 'success');
        loadCart();
    } catch (error) {
        showToast(error.message, 'error');
    }
}

// ============================================
// WEATHER
// ============================================
function initWeather() {
    document.getElementById('searchWeather').addEventListener('click', () => {
        const city = document.getElementById('weatherCity').value;
        if (city) loadWeather(city);
    });
    document.getElementById('weatherCity').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const city = document.getElementById('weatherCity').value;
            if (city) loadWeather(city);
        }
    });
}

async function loadWeather(city) {
    const queryCity = city || document.getElementById('weatherCity').value || 'Delhi';
    
    try {
        // Load current weather
        const [currentData, forecastData] = await Promise.all([
            apiRequest(`/weather/current?city=${encodeURIComponent(queryCity)}`),
            apiRequest(`/weather/forecast?city=${encodeURIComponent(queryCity)}`)
        ]);

        // Current weather
        const w = currentData.weather;
        document.getElementById('weatherCurrent').innerHTML = `
            <div>
                <img src="https://openweathermap.org/img/wn/${w.icon}@4x.png" alt="${w.description}" style="width:100px;height:100px;margin:0 auto">
                <h2>${w.city}, ${w.country}</h2>
                <div class="temp">${Math.round(w.temperature)}°C</div>
                <div class="condition">Feels like ${Math.round(w.feelsLike)}°C - ${w.description}</div>
                <div class="weather-details">
                    <div class="weather-detail-item">
                        <i class="fas fa-tint"></i>
                        <span class="label">Humidity</span>
                        <span class="value">${w.humidity}%</span>
                    </div>
                    <div class="weather-detail-item">
                        <i class="fas fa-wind"></i>
                        <span class="label">Wind</span>
                        <span class="value">${w.windSpeed} m/s</span>
                    </div>
                    <div class="weather-detail-item">
                        <i class="fas fa-compress-arrows-alt"></i>
                        <span class="label">Pressure</span>
                        <span class="value">${w.pressure} hPa</span>
                    </div>
                    <div class="weather-detail-item">
                        <i class="fas fa-eye"></i>
                        <span class="label">Visibility</span>
                        <span class="value">${(w.visibility / 1000).toFixed(1)} km</span>
                    </div>
                    <div class="weather-detail-item">
                        <i class="fas fa-cloud"></i>
                        <span class="label">Clouds</span>
                        <span class="value">${w.cloudiness}%</span>
                    </div>
                    <div class="weather-detail-item">
                        <i class="fas fa-sun"></i>
                        <span class="label">Sunrise</span>
                        <span class="value">${new Date(w.sunrise * 1000).toLocaleTimeString()}</span>
                    </div>
                </div>
            </div>
        `;

        // 7-day forecast
        if (forecastData.forecast) {
            const forecastGrid = document.getElementById('forecastGrid');
            forecastGrid.innerHTML = forecastData.forecast.map(day => `
                <div class="forecast-card">
                    <div class="date">${new Date(day.date).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}</div>
                    <img src="https://openweathermap.org/img/wn/${day.icon}@2x.png" alt="${day.description}" style="width:50px;height:50px;margin:0 auto">
                    <div class="temp-range">${Math.round(day.minTemp)}° / ${Math.round(day.maxTemp)}°C</div>
                    <div class="rain"><i class="fas fa-tint"></i> ${day.rainProbability}% rain</div>
                    <div class="desc" style="text-transform:capitalize">${day.description}</div>
                </div>
            `).join('');
        }
    } catch (error) {
        document.getElementById('weatherCurrent').innerHTML = 
            '<div style="text-align:center;color:#fff"><i class="fas fa-exclamation-triangle" style="font-size:2rem;margin-bottom:1rem"></i><p>Unable to fetch weather data. Please check the city name and try again.</p></div>';
    }
}

// ============================================
// MARKET PRICES
// ============================================
function initMarketPrices() {
    document.getElementById('searchMarketBtn').addEventListener('click', () => {
        const q = document.getElementById('searchMarket').value;
        searchMarket(q);
    });
    document.getElementById('chartCrop').addEventListener('change', () => {
        loadPriceChart(document.getElementById('chartCrop').value);
    });
    document.getElementById('searchMarket').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const q = document.getElementById('searchMarket').value;
            searchMarket(q);
        }
    });
}

async function loadMarketPrices() {
    try {
        const data = await apiRequest('/market/prices');
        const container = document.getElementById('pricesOverview');
        
        if (data.data && Array.isArray(data.data)) {
            container.innerHTML = '<div class="prices-overview">' + data.data.map(item => {
                const trendClass = item.trend?.direction || 'stable';
                const trendIcon = trendClass === 'up' ? '↑' : trendClass === 'down' ? '↓' : '→';
                return `
                    <div class="price-card">
                        <div class="crop-name" style="text-transform:capitalize">${item.crop}</div>
                        <div class="crop-price">₹${item.latest.modalPrice}</div>
                        <div class="crop-unit">/${item.latest.unit} (${item.latest.market})</div>
                        <div class="price-trend ${trendClass}">
                            <span>${trendIcon} ${item.trend?.percentage || 0}%</span>
                        </div>
                    </div>
                `;
            }).join('') + '</div>';
        }

        // Load initial chart
        loadPriceChart('rice');
    } catch (error) {
        document.getElementById('pricesOverview').innerHTML = '<p class="text-center">Failed to load market prices.</p>';
    }
}

async function searchMarket(query) {
    if (!query) return;
    try {
        const data = await apiRequest(`/market/search?q=${encodeURIComponent(query)}`);
        const container = document.getElementById('pricesOverview');
        
        if (data.results && data.results.length > 0) {
            container.innerHTML = '<div class="prices-overview">' + data.results.map(item => {
                const trendClass = item.trend?.direction || 'stable';
                const trendIcon = trendClass === 'up' ? '↑' : trendClass === 'down' ? '↓' : '→';
                return `
                    <div class="price-card">
                        <div class="crop-name" style="text-transform:capitalize">${item.crop}</div>
                        <div class="crop-price">₹${item.latest.modalPrice}</div>
                        <div class="crop-unit">/${item.latest.unit} (${item.latest.market})</div>
                        <div class="price-trend ${trendClass}">
                            <span>${trendIcon} ${item.trend?.percentage || 0}%</span>
                        </div>
                    </div>
                `;
            }).join('') + '</div>';
        } else {
            container.innerHTML = '<p class="text-center">No results found for "' + query + '"</p>';
        }
    } catch (error) {
        showToast('Search failed', 'error');
    }
}

function loadPriceChart(crop) {
    const ctx = document.getElementById('priceChart');
    if (!ctx) return;

    // Destroy existing chart
    if (state.priceChart) state.priceChart.destroy();

    // Fetch trend data
    apiRequest(`/market/trends?crop=${crop}`).then(data => {
        if (data.historical) {
            const labels = data.historical.map(d => d.date);
            const modalPrices = data.historical.map(d => d.modalPrice);
            const minPrices = data.historical.map(d => d.minPrice);
            const maxPrices = data.historical.map(d => d.maxPrice);

            const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
            const textColor = isDark ? '#e2e8f0' : '#1e293b';
            const gridColor = isDark ? '#334155' : '#e2e8f0';

            state.priceChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels,
                    datasets: [
                        {
                            label: 'Modal Price',
                            data: modalPrices,
                            borderColor: '#2d8a4e',
                            backgroundColor: 'rgba(45, 138, 78, 0.1)',
                            borderWidth: 3,
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Min Price',
                            data: minPrices,
                            borderColor: '#3b82f6',
                            borderWidth: 2,
                            borderDash: [5, 5],
                            fill: false,
                            tension: 0.4
                        },
                        {
                            label: 'Max Price',
                            data: maxPrices,
                            borderColor: '#ef4444',
                            borderWidth: 2,
                            borderDash: [5, 5],
                            fill: false,
                            tension: 0.4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { labels: { color: textColor } },
                        title: {
                            display: true,
                            text: `${crop.charAt(0).toUpperCase() + crop.slice(1)} Price Trend`,
                            color: textColor,
                            font: { size: 16 }
                        }
                    },
                    scales: {
                        x: { ticks: { color: textColor }, grid: { color: gridColor } },
                        y: { ticks: { color: textColor }, grid: { color: gridColor } }
                    }
                }
            });
        }
    }).catch(() => {
        // Fallback data
        const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const prices = [3000, 3050, 3100, 3080, 3120, 3150, 3180];
        
        state.priceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: 'Price (₹/quintal)',
                    data: prices,
                    borderColor: '#2d8a4e',
                    backgroundColor: 'rgba(45, 138, 78, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: { responsive: true, plugins: { title: { display: true, text: `${crop} Price Trend` } } }
        });
    });
}

// ============================================
// AI CHAT
// ============================================
function initChat() {
    document.getElementById('sendChat').addEventListener('click', sendMessage);
    document.getElementById('chatInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
}

async function loadAISuggestions() {
    try {
        const data = await apiRequest('/ai/suggestions');
        const grid = document.getElementById('suggestionsGrid');
        if (data.suggestions) {
            grid.innerHTML = data.suggestions.map(s => `
                <button class="suggestion-btn" onclick="sendSuggestion('${s.query.replace(/'/g, "\\'")}')">
                    <i class="fas fa-comment-dots"></i>
                    <span>${s.topic}</span>
                </button>
            `).join('');
        }
    } catch (error) {
        // Use fallback suggestions
        const fallback = [
            { topic: 'Crop Recommendations', query: 'What crops should I grow this season in North India?' },
            { topic: 'Disease Prevention', query: 'How to prevent blight in tomato crops?' },
            { topic: 'Fertilizer Guide', query: 'What fertilizers are best for wheat cultivation?' },
            { topic: 'Irrigation Tips', query: 'Best irrigation methods for small farms?' },
            { topic: 'Government Schemes', query: 'What government schemes are available for farmers?' },
            { topic: 'Organic Farming', query: 'How to start organic farming?' },
            { topic: 'Weather Advice', query: 'How does rainfall pattern affect crop selection?' },
            { topic: 'Pest Control', query: 'Natural ways to control pests without chemicals?' }
        ];
        const grid = document.getElementById('suggestionsGrid');
        grid.innerHTML = fallback.map(s => `
            <button class="suggestion-btn" onclick="sendSuggestion(\`${s.query}\`)">
                <i class="fas fa-comment-dots"></i>
                <span>${s.topic}</span>
            </button>
        `).join('');
    }
}

function sendSuggestion(query) {
    document.getElementById('chatInput').value = query;
    sendMessage();
}

async function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    if (!message) return;

    if (!state.user) {
        showToast('Please login to use AI Assistant', 'info');
        navigateTo('login');
        return;
    }

    // Add user message to chat
    appendMessage('user', message);
    input.value = '';

    // Add typing indicator
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot';
    typingDiv.innerHTML = '<div class="message-content"><p><i class="fas fa-spinner fa-spin"></i> Thinking...</p></div>';
    typingDiv.id = 'typingIndicator';
    document.getElementById('chatMessages').appendChild(typingDiv);
    scrollToBottom();

    // Add to conversation history
    state.chatHistory.push({ role: 'user', content: message });

    try {
        const data = await apiRequest('/ai/chat', {
            method: 'POST',
            body: JSON.stringify({ message, conversation: state.chatHistory.slice(-6) })
        });

        // Remove typing indicator
        const typing = document.getElementById('typingIndicator');
        if (typing) typing.remove();

        // Add bot response
        appendMessage('bot', data.response);
        state.chatHistory.push({ role: 'assistant', content: data.response });
    } catch (error) {
        const typing = document.getElementById('typingIndicator');
        if (typing) typing.remove();
        
        // Fallback response
        const fallbackResponses = {
            'crop': 'Based on your region, I recommend growing wheat and mustard during Rabi season, and rice and maize during Kharif season. Consider your soil type and water availability before making a final decision.',
            'disease': 'Common crop diseases include leaf blight, powdery mildew, and root rot. Prevention tips: 1) Practice crop rotation, 2) Use resistant varieties, 3) Maintain proper spacing, 4) Apply fungicide at first sign of symptoms, 5) Remove infected plants immediately.',
            'fertilizer': 'For optimal crop yield, use NPK fertilizers based on soil testing. Generally: Nitrogen promotes leaf growth, Phosphorus helps root development, and Potassium strengthens stems. Always follow recommended dosages and apply at the right growth stage.',
            'irrigation': 'Best irrigation methods for Indian farms: 1) Drip irrigation (saves 30-50% water), 2) Sprinkler system (good for row crops), 3) Flood irrigation (traditional, uses more water). Consider solar-powered pumps to reduce costs.',
            'scheme': 'Key Government Schemes for Farmers:\n• PM-KISAN: ₹6,000/year in 3 installments\n• Kisan Credit Card: Loans up to ₹3 lakhs at 7% interest\n• PM Fasal Bima Yojana: Crop insurance at affordable premiums\n• Soil Health Card: Free soil testing\n• eNAM: National Agriculture Market for online trading',
            'default': 'Thank you for your question. As an AI agricultural assistant, I can help with crop recommendations, disease prevention, fertilizer suggestions, irrigation advice, and government schemes. Could you please provide more details about your specific query?'
        };

        const lowerMsg = message.toLowerCase();
        let response = fallbackResponses.default;
        if (lowerMsg.includes('crop') || lowerMsg.includes('grow') || lowerMsg.includes('plant')) response = fallbackResponses.crop;
        else if (lowerMsg.includes('disease') || lowerMsg.includes('pest') || lowerMsg.includes('blight')) response = fallbackResponses.disease;
        else if (lowerMsg.includes('fertilizer') || lowerMsg.includes('nutrient') || lowerMsg.includes('npk')) response = fallbackResponses.fertilizer;
        else if (lowerMsg.includes('irrigation') || lowerMsg.includes('water') || lowerMsg.includes('watering')) response = fallbackResponses.irrigation;
        else if (lowerMsg.includes('scheme') || lowerMsg.includes('government') || lowerMsg.includes('subsidy')) response = fallbackResponses.scheme;

        appendMessage('bot', response);
        state.chatHistory.push({ role: 'assistant', content: response });
    }
}

function appendMessage(role, content) {
    const messages = document.getElementById('chatMessages');
    const div = document.createElement('div');
    div.className = `message ${role}`;
    
    // Convert markdown-like formatting to HTML
    let formattedContent = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/\n/g, '<br>')
        .replace(/• /g, '• ');
    
    div.innerHTML = `<div class="message-content"><p>${formattedContent}</p></div>`;
    messages.appendChild(div);
    scrollToBottom();
}

function scrollToBottom() {
    const messages = document.getElementById('chatMessages');
    messages.scrollTop = messages.scrollHeight;
}

// ============================================
// DASHBOARD
// ============================================
async function loadDashboard() {
    if (!state.user) return;

    document.getElementById('dashboardUserName').textContent = state.user.name;

    if (state.user.role === 'farmer' || state.user.role === 'supplier') {
        document.getElementById('addListingSection').style.display = 'block';
        document.getElementById('inquiriesSection').style.display = 'block';
        document.getElementById('cartSection').style.display = 'none';
        
        try {
            const data = await apiRequest('/dashboard/farmer');
            const stats = data.dashboard.stats;
            document.getElementById('statListings').textContent = stats.totalListings;
            document.getElementById('statEarnings').textContent = '₹' + stats.totalEarnings.toLocaleString();
            document.getElementById('statInquiries').textContent = stats.totalInquiries;
            document.getElementById('statOrders').textContent = stats.completedOrders;

            // Load recent orders
            const ordersContainer = document.getElementById('recentOrders');
            if (data.dashboard.recentOrders && data.dashboard.recentOrders.length > 0) {
                ordersContainer.innerHTML = data.dashboard.recentOrders.map(order => createOrderCard(order)).join('');
            } else {
                ordersContainer.innerHTML = '<p class="text-center">No orders yet</p>';
            }

            // Load inquiries
            const inquiriesContainer = document.getElementById('inquiriesList');
            if (data.dashboard.recentInquiries && data.dashboard.recentInquiries.length > 0) {
                inquiriesContainer.innerHTML = data.dashboard.recentInquiries.map(inq => `
                    <div class="order-card">
                        <div style="display:flex;justify-content:space-between">
                            <strong>${inq.inquiry.buyer?.name || 'Buyer'}</strong>
                            <span class="order-status status-${inq.inquiry.status}">${inq.inquiry.status}</span>
                        </div>
                        <p style="color:var(--text-secondary);margin:0.5rem 0">${inq.inquiry.message}</p>
                        <small style="color:var(--text-muted)">Regarding: ${inq.crop.title} - ₹${inq.crop.price}/${inq.crop.unit}</small>
                    </div>
                `).join('');
            } else {
                inquiriesContainer.innerHTML = '<p class="text-center">No inquiries yet</p>';
            }

            // Load my listings
            const myListingsContainer = document.getElementById('myListingsGrid');
            if (data.dashboard.recentCrops && data.dashboard.recentCrops.length > 0) {
                myListingsContainer.innerHTML = '<div class="products-grid">' + 
                    data.dashboard.recentCrops.map(crop => createCropCard(crop)).join('') + '</div>';
            } else {
                myListingsContainer.innerHTML = '<p class="text-center">No listings yet. Create your first listing above!</p>';
            }
        } catch (error) {
            showToast('Failed to load dashboard data', 'error');
        }
    } else if (state.user.role === 'buyer') {
        document.getElementById('addListingSection').style.display = 'none';
        document.getElementById('inquiriesSection').style.display = 'none';
        document.getElementById('cartSection').style.display = 'block';
        
        try {
            const data = await apiRequest('/dashboard/buyer');
            const stats = data.dashboard.stats;
            document.getElementById('statListings').textContent = stats.totalOrders;
            document.getElementById('statEarnings').textContent = '₹' + stats.totalSpent.toLocaleString();
            document.getElementById('statInquiries').textContent = stats.pendingOrders;
            document.getElementById('statOrders').textContent = stats.cartItems;

            loadCart();

            const ordersContainer = document.getElementById('recentOrders');
            if (data.dashboard.recentOrders && data.dashboard.recentOrders.length > 0) {
                ordersContainer.innerHTML = data.dashboard.recentOrders.map(order => createOrderCard(order)).join('');
            } else {
                ordersContainer.innerHTML = '<p class="text-center">No orders yet</p>';
            }
        } catch (error) {
            showToast('Failed to load dashboard data', 'error');
        }
    }
}

function createOrderCard(order) {
    return `
        <div class="order-card">
            <div class="order-header">
                <span class="order-number">${order.orderNumber}</span>
                <span class="order-status status-${order.status}">${order.status}</span>
            </div>
            <div style="color:var(--text-secondary);font-size:0.9rem">
                <span>${new Date(order.createdAt).toLocaleDateString()}</span>
                <span style="margin:0 0.5rem">|</span>
                <span>${order.buyer?.name || 'Buyer'}</span>
                <span style="margin:0 0.5rem">|</span>
                <strong style="color:var(--primary)">₹${order.totalAmount?.toFixed(2) || '0.00'}</strong>
            </div>
            <div style="margin-top:0.5rem">
                ${(order.items || []).map(item => `<span style="background:var(--bg-alt);padding:0.25rem 0.5rem;border-radius:4px;font-size:0.8rem;margin-right:0.5rem">${item.title} x${item.quantity}</span>`).join('')}
            </div>
        </div>
    `;
}

// Add Crop Listing
document.getElementById('addCropForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData();
    formData.append('title', document.getElementById('cropTitle').value);
    formData.append('category', document.getElementById('cropCategory').value);
    formData.append('price', document.getElementById('cropPrice').value);
    formData.append('unit', document.getElementById('cropUnit').value);
    formData.append('quantity', document.getElementById('cropQuantity').value);
    formData.append('quality', document.getElementById('cropQuality').value);
    formData.append('isOrganic', document.getElementById('cropOrganic').checked);
    formData.append('description', document.getElementById('cropDescription').value);
    
    const location = {
        city: document.getElementById('cropCity').value,
        state: document.getElementById('cropState').value
    };
    formData.append('location', JSON.stringify(location));

    // Add images
    const images = document.getElementById('cropImages').files;
    for (let img of images) {
        formData.append('images', img);
    }

    try {
        await apiRequest('/crops', {
            method: 'POST',
            body: formData
        });
        showMessage('addCropMessage', 'Crop listing created successfully!', 'success');
        e.target.reset();
        loadDashboard();
        showToast('New crop listing created!', 'success');
    } catch (error) {
        showMessage('addCropMessage', error.message, 'error');
    }
});

// ============================================
// PROFILE
// ============================================
function loadProfile() {
    if (!state.user) return;
    document.getElementById('profileName').value = state.user.name || '';
    document.getElementById('profileEmail').value = state.user.email || '';
    document.getElementById('profilePhone').value = state.user.phone || '';
    document.getElementById('profileRole').value = state.user.role || '';
    document.getElementById('profileCity').value = state.user.address?.city || '';
    document.getElementById('profileState').value = state.user.address?.state || '';
    document.getElementById('profilePincode').value = state.user.address?.pincode || '';

    // Show farm details for farmers
    if (state.user.role === 'farmer') {
        document.getElementById('farmDetailsSection').style.display = 'block';
        document.getElementById('profileFarmName').value = state.user.farmDetails?.farmName || '';
        document.getElementById('profileFarmSize').value = state.user.farmDetails?.farmSize || '';
        document.getElementById('profileLandType').value = state.user.farmDetails?.landType || 'mixed';
    }
}

document.getElementById('profileForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
        name: document.getElementById('profileName').value,
        phone: document.getElementById('profilePhone').value,
        address: {
            city: document.getElementById('profileCity').value,
            state: document.getElementById('profileState').value,
            pincode: document.getElementById('profilePincode').value
        }
    };

    if (state.user.role === 'farmer') {
        data.farmDetails = {
            farmName: document.getElementById('profileFarmName').value,
            farmSize: document.getElementById('profileFarmSize').value,
            landType: document.getElementById('profileLandType').value
        };
    }

    try {
        const result = await apiRequest('/auth/profile', {
            method: 'PUT',
            body: JSON.stringify(data)
        });
        state.user = result.user;
        localStorage.setItem('user', JSON.stringify(result.user));
        showMessage('profileMessage', 'Profile updated successfully!', 'success');
        showToast('Profile updated!', 'success');
    } catch (error) {
        showMessage('profileMessage', error.message, 'error');
    }
});

// ============================================
// ORDERS
// ============================================
async function loadOrders() {
    if (!state.user) return;
    try {
        const data = await apiRequest('/orders');
        const container = document.getElementById('ordersList');
        
        if (data.orders && data.orders.length > 0) {
            container.innerHTML = data.orders.map(order => createOrderCard(order)).join('');
        } else {
            container.innerHTML = '<p class="text-center">No orders found</p>';
        }
    } catch (error) {
        document.getElementById('ordersList').innerHTML = '<p class="text-center">Failed to load orders</p>';
    }
}

// ============================================
// FILTERS
// ============================================
function initFilters() {
    // Crops filters
    document.getElementById('applyFilters').addEventListener('click', () => { state.cropsPage = 1; loadCrops(); });
    document.getElementById('resetFilters').addEventListener('click', () => {
        document.getElementById('filterCategory').value = '';
        document.getElementById('filterState').value = '';
        document.getElementById('filterMinPrice').value = '';
        document.getElementById('filterMaxPrice').value = '';
        document.getElementById('filterQuality').value = '';
        document.getElementById('filterOrganic').checked = false;
        document.getElementById('searchCrops').value = '';
        state.cropsPage = 1;
        loadCrops();
    });
    document.getElementById('searchCrops').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') { state.cropsPage = 1; loadCrops(); }
    });

    // Equipment filters
    document.getElementById('applyEquipFilters').addEventListener('click', () => { state.equipmentPage = 1; loadEquipment(); });

    // Fertilizer filters
    document.getElementById('applyFertFilters').addEventListener('click', () => { state.fertilizersPage = 1; loadFertilizers(); });
    document.getElementById('searchFertilizers').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') { state.fertilizersPage = 1; loadFertilizers(); }
    });

    // Category cards on home
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('filterCategory').value = card.dataset.category;
            navigateTo('marketplace');
        });
    });
}

// ============================================
// UTILITIES
// ============================================
function renderPagination(containerId, pagination, callback) {
    const container = document.getElementById(containerId);
    if (!pagination || pagination.pages <= 1) {
        container.innerHTML = '';
        return;
    }

    let html = '';
    if (pagination.page > 1) {
        html += `<button onclick="window._pageCallback(${pagination.page - 1})">Prev</button>`;
    }
    for (let i = 1; i <= pagination.pages; i++) {
        html += `<button class="${i === pagination.page ? 'active' : ''}" onclick="window._pageCallback(${i})">${i}</button>`;
    }
    if (pagination.page < pagination.pages) {
        html += `<button onclick="window._pageCallback(${pagination.page + 1})">Next</button>`;
    }
    container.innerHTML = html;
    window._pageCallback = callback;
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = { success: 'check-circle', error: 'exclamation-circle', info: 'info-circle' };
    toast.innerHTML = `<i class="fas fa-${icons[type] || 'info-circle'}"></i><span>${message}</span>`;
    
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

function showMessage(elementId, message, type) {
    const el = document.getElementById(elementId);
    if (el) {
        el.textContent = message;
        el.className = `form-message ${type}`;
    }
}

function submitInquiry(cropId) {
    if (!state.user) {
        showToast('Please login to send an inquiry', 'info');
        navigateTo('login');
        return;
    }

    const message = prompt('Enter your inquiry message:');
    if (message) {
        apiRequest(`/crops/${cropId}/inquiry`, {
            method: 'POST',
            body: JSON.stringify({ message })
        }).then(() => {
            showToast('Inquiry sent successfully!', 'success');
        }).catch(() => {
            showToast('Failed to send inquiry', 'error');
        });
    }
}
